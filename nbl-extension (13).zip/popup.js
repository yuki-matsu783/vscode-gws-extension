// 入力欄(検索/URL/テキスト)とダウンロード一覧。実処理は background.js(notebook-task / send-download)。
const $ = (id) => document.getElementById(id), msg = $("msg"), list = $("list");
// ── 送信先ノートブックの選択(storage.sync.notebookUrl が既定の送信先。ここで切り替えると以降の全操作に効く)
const sel = $("target");
const STALE_MS = 30 * 60 * 1000; // この時間より古ければ、開いたときに自動で取り直す
const short = (id) => (id || "").slice(0, 8);
async function renderTargets(extra) {
  const { notebooks = [], notebookUrl = "" } = await chrome.storage.sync.get(["notebooks", "notebookUrl"]);
  const { notebookCache } = await chrome.storage.local.get("notebookCache");
  const all = [...(extra || []), ...(notebookCache?.items || []), ...notebooks];
  const seen = new Set(), items = all.filter((n) => !seen.has(n.url) && seen.add(n.url));
  if (notebookUrl && !seen.has(notebookUrl)) items.unshift({ url: notebookUrl, title: "(設定済みのURL)" });
  sel.innerHTML = "";
  if (!notebookUrl) { const o = document.createElement("option"); o.value = ""; o.textContent = "— 送信先を選んでください —"; sel.append(o); }
  for (const n of items) {
    const id = (/\/notebook\/([0-9a-f-]{36})/.exec(n.url) || [])[1];
    const o = document.createElement("option"); o.value = n.url; o.dataset.title = n.title || "";
    o.textContent = (n.emoji || "") + (n.title || "無題") + (id ? "  [" + short(id) + "]" : "") + (n.meta ? "  — " + n.meta : "");
    sel.append(o);
  }
  sel.value = notebookUrl || "";
  return notebookCache;
}
async function refreshTargets(force) {
  const cache = await renderTargets();
  if (!force && cache && Date.now() - cache.at < STALE_MS) return;
  msg.textContent = "ノートブック一覧を取得中…";
  const r = await chrome.runtime.sendMessage({ type: "refresh-notebooks" });
  await renderTargets();
  msg.textContent = r?.ok ? r.notebooks.length + "件の一覧を更新しました" : "一覧の取得に失敗: " + (r?.error || "");
}
sel.onchange = async () => {
  const o = sel.selectedOptions[0];
  const { notebooks = [] } = await chrome.storage.sync.get("notebooks");
  const m = /\/notebook\/([0-9a-f-]{36})/.exec(sel.value);
  if (m && !notebooks.some((n) => n.url === sel.value)) notebooks.unshift({ id: m[1], url: sel.value, title: o.dataset.title || "" });
  await chrome.storage.sync.set({ notebookUrl: sel.value, notebooks });
  msg.textContent = "送信先を切り替えました";
};
$("reload").onclick = () => refreshTargets(true);
$("nbSearch").onclick = async () => {
  msg.textContent = "ノートブックを検索中…";
  const r = await chrome.runtime.sendMessage({ type: "list-notebooks", query: $("nbq").value.trim() });
  if (!r?.ok) { msg.textContent = "失敗: " + (r?.error || ""); return; }
  await renderTargets(r.notebooks); msg.textContent = r.notebooks.length + "件(選ぶと送信先になります)";
};
$("nbNew").onclick = async () => {
  msg.textContent = "ノートブックを作成中…";
  const r = await chrome.runtime.sendMessage({ type: "create-notebook", title: $("nbq").value.trim(), makeDefault: true });
  if (!r?.ok) { msg.textContent = "失敗: " + (r?.error || ""); return; }
  await renderTargets(); msg.textContent = "作成して送信先にしました";
};
// 削除(完全削除・復元不可)。2段階: 1回目で内容を表示して確認待ち(5秒)、2回目で実行。
let delArmed = null;
$("nbDel").onclick = async () => {
  const o = sel.selectedOptions[0], m = /\/notebook\/([0-9a-f-]{36})/.exec(sel.value || "");
  if (!o || !m) { msg.textContent = "削除できるノートブックを選んでください"; return; }
  const title = o.dataset.title || null; // 一覧から得たタイトル(取得元が無ければ null=タイトル照合なし)
  if (delArmed !== m[1]) {
    delArmed = m[1]; $("nbDel").textContent = "本当に削除する: 「" + title + "」(5秒以内にもう一度)";
    setTimeout(() => { delArmed = null; $("nbDel").textContent = "選択中のノートブックを削除…"; }, 5000); return;
  }
  delArmed = null; $("nbDel").textContent = "選択中のノートブックを削除…"; msg.textContent = "削除中…";
  const r = await chrome.runtime.sendMessage({ type: "delete-notebook", id: m[1], title });
  msg.textContent = r?.ok ? "削除しました" : "失敗: " + (r?.error || "");
  await renderTargets();
};
refreshTargets(false);

// チャット履歴の削除(復元不可)。「動作確認」は確認ダイアログを開いて閉じるだけ。削除は2段階(5秒以内にもう一度)。
$("chatDelCheck").onclick = () => run({ type: "clearchat", dryRun: true }, "確認中");
let chatDelArmed = false;
$("chatDel").onclick = async () => {
  const o = sel.selectedOptions[0];
  const name = (o && (o.dataset.title || o.textContent)) || "現在の送信先";
  if (!chatDelArmed) {
    chatDelArmed = true; $("chatDel").textContent = "本当に削除: 「" + name + "」のチャット(5秒以内にもう一度)";
    setTimeout(() => { chatDelArmed = false; $("chatDel").textContent = "選択中の履歴を削除…"; }, 5000); return;
  }
  chatDelArmed = false; $("chatDel").textContent = "選択中の履歴を削除…";
  await run({ type: "clearchat", dryRun: false }, "チャット履歴を削除中");
};

async function run(task, label) {
  msg.textContent = label + "…(完了は通知で表示。ポップアップは閉じてOK)";
  const r = await chrome.runtime.sendMessage({ type: "notebook-task", task: { ...task, notebookUrl: sel.value || undefined } });
  if (task.type === "chat" && r?.ok) { showAnswer(r.message); msg.textContent = "回答を取得しました"; return; }
  msg.textContent = r?.ok ? "完了: " + r.message : "失敗: " + (r?.error || "");
}
function showAnswer(t) { $("ans").style.display = "block"; $("ans").textContent = t; }
// ソースの「全件/最新のみ」トグル。選んだ値は保存され、次回も維持される(右クリック等の経路でも同じ設定を使う)
chrome.storage.sync.get({ studioSources: "all" }).then(({ studioSources }) => {
  const r = document.querySelector(`input[name=stSrc][value=${studioSources === "last" ? "last" : "all"}]`); if (r) r.checked = true;
});
document.querySelectorAll("input[name=stSrc]").forEach((r) => (r.onchange = () => chrome.storage.sync.set({ studioSources: r.value })));
$("goStudio").onclick = () => {
  const options = {};
  for (const line of $("stOpts").value.split(/\n/)) { const m = /^\s*(.*?)\s*[:：]\s*(.+?)\s*$/.exec(line); if (m) options[m[1]] = m[2]; }
  const kind = $("stKind").value;
  run({ type: "studio", kind, prompt: $("stPrompt").value.trim() || undefined, options, randomStyle: kind === "infographic" && $("stRand").checked, sources: document.querySelector('input[name=stSrc]:checked')?.value === "last" ? "last" : "all", download: $("stDl").checked }, "Studio で生成中");
};
$("goAsk").onclick = () => { const q = $("ask").value.trim(); if (q) run({ type: "chat", prompt: q }, "質問中"); };
$("copyAns").onclick = async () => { await navigator.clipboard.writeText($("ans").textContent); msg.textContent = "Markdownをコピーしました"; };
$("copyPlain").onclick = async () => { const { lastChat } = await chrome.storage.local.get("lastChat"); await navigator.clipboard.writeText(lastChat?.answer || $("ans").textContent); msg.textContent = "テキストをコピーしました"; };
// 閉じて開き直しても、最後の回答を見られるようにする
chrome.storage.local.get("lastChat").then(({ lastChat }) => { if (lastChat) { showAnswer(lastChat.markdown || lastChat.answer); $("ask").placeholder = "前回: " + lastChat.prompt.slice(0, 30); } });
$("goSearch").onclick = () => { const q = $("q").value.trim(); if (q) run({ type: "search", query: q, mode: $("mode").value, scope: $("scope").value }, "検索中"); };
$("goUrls").onclick = () => { const u = $("urls").value.split(/\s+/).filter((x) => /^https?:\/\//.test(x)); if (u.length) run({ type: "urls", urls: u }, "URLを追加中"); else msg.textContent = "http(s):// で始まるURLを入れてください"; };
$("goTab").onclick = async () => { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); if (/^https?:/.test(t?.url || "")) run({ type: "urls", urls: [t.url] }, "ページを追加中"); else msg.textContent = "このページは追加できません"; };
$("goText").onclick = () => { const t = $("text").value.trim(); if (t) run({ type: "text", text: t }, "テキストを追加中"); };
$("goClip").onclick = async () => { try { const t = (await navigator.clipboard.readText()).trim(); if (t) run({ type: "text", text: t }, "クリップボードを追加中"); else msg.textContent = "クリップボードが空です"; } catch (e) { msg.textContent = "クリップボードを読めません: " + e.message; } };
(async () => {
  const items = await chrome.downloads.search({ state: "complete", orderBy: ["-startTime"], limit: 5 });
  if (!items.length) list.textContent = "ダウンロード履歴がありません";
  for (const it of items) {
    const li = document.createElement("li");
    const n = document.createElement("span"); n.className = "n"; n.textContent = it.filename.split(/[\\/]/).pop(); n.title = it.filename;
    const b = document.createElement("button"); b.textContent = "追加";
    b.onclick = async () => {
      b.disabled = true; msg.textContent = "送信中…(完了は通知で表示)";
      const r = await chrome.runtime.sendMessage({ type: "send-download", id: it.id });
      msg.textContent = r?.ok ? "追加しました" : "失敗: " + (r?.error || "");
      b.disabled = false;
    };
    li.append(n, b); list.append(li);
  }
})();
$("opt").onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };

// 直近の失敗の全文(通知は途中で切れるため)。原因調査に使う。
chrome.storage.local.get("lastError").then(({ lastError }) => {
  if (!lastError || Date.now() - lastError.at > 24 * 3600 * 1000) return;
  $("errBox").style.display = "block";
  $("errText").textContent = new Date(lastError.at).toLocaleString() + "\n" + lastError.title + "\n" + lastError.message;
});

chrome.storage.local.get("trace").then(({ trace }) => { $("traceText").textContent = (trace || []).join("\n") || "(まだ記録がありません)"; });

// キュー(最大10件)。待ち中のジョブは✕で取り消せる(実行中は取り消せない)。
async function renderQueue() {
  const r = await chrome.runtime.sendMessage({ type: "queue-list" });
  const jobs = r?.jobs || [];
  $("qCount").textContent = jobs.length;
  const ul = $("qList"); ul.innerHTML = "";
  for (const j of jobs) {
    const li = document.createElement("li");
    const n = document.createElement("span"); n.className = "n"; n.textContent = (j.running ? "▶ " : "· ") + j.label;
    li.append(n);
    if (!j.running) { const x = document.createElement("button"); x.textContent = "✕"; x.onclick = async () => { await chrome.runtime.sendMessage({ type: "queue-remove", id: j.id }); renderQueue(); }; li.append(x); }
    ul.append(li);
  }
}
$("qClear").onclick = async () => { const r = await chrome.runtime.sendMessage({ type: "queue-clear" }); msg.textContent = r?.ok ? "待機中の" + r.removed + "件を消しました" : "失敗"; renderQueue(); };
renderQueue(); setInterval(renderQueue, 3000);
