/**
 * ============================================================================
 *  page/uploader.js — notebook.google.com のページ「の中」で動く部分(MAIN world)
 * ============================================================================
 *
 * 【役割分担】
 *   background.js(拡張のService Worker)がこのファイルを notebook のタブに注入し、
 *   window.__nblUploadFiles(files, cfg) を呼ぶ。このファイルがやるのは次の4つだけ。
 *     1. 「ソースを追加」ダイアログが見える状態にする(タブ/ソースパネルの状態を問わない)
 *     2. 「ファイルをアップロード」ボタンが押されたら、アプリが作る <input type=file> を乗っ取って
 *        渡された File を流し込む(OS のファイル選択ダイアログは開かない)
 *     3. ソース一覧に追加されたことを確認する
 *     4. 触った画面状態(タブ・パネル)を元に戻す
 *   「ボタンを押す」こと自体は、このファイルではできない。理由は次のとおり。
 *
 * 【重要な制約(実機で確認した事実)】
 *   「ファイルをアップロード」ボタンは、スクリプトが出す click()(isTrusted=false)を無視する。
 *   本物のクリック(isTrusted=true)だけが通る。
 *   → このファイルはボタンの座標を window.__nblNeedClick = { x, y, width, height, clickable } に出して待つ。
 *     拡張の background.js が chrome.debugger(CDP の Input.dispatchMouseEvent)で
 *     その座標に「本物と同じクリック」を送る。クリックが通ると、window.__nblNeedClick は消える。
 *
 * 【結果の受け渡し】
 *   background.js は __nblUploadFiles() を待たずに呼び(クリック待ちで止まるため)、
 *   結果は window.__nblResult に入るのをポーリングで読む。
 *
 * 【サイトの見た目・構造が変わったとき】
 *   直すのは「SITE」だけ。操作のロジックは SITE 経由でしか DOM に触れない。
 *   (単体のユーザースクリプト版 notebook_uploader_pageobject.js と同じ SITE / 同じ処理。
 *    こちらは IndexedDB ではなく、渡された File を使う点だけが違う)
 *
 * 【対応している画面レイアウト(実機で確認)】
 *   A. 広い幅: 3カラム。ソースパネルは開閉でき、閉じるとソース一覧が DOM から消える。
 *   B. 狭い幅(約700px以下): Sources / チャット / Studio のタブ表示。
 *      「チャット」「Studio」タブでは「ソースを追加」が DOM にあっても表示されていない。
 *   → 実行時に見える状態にし、終わったら元に戻す。表示言語は日本語前提。
 */
(() => {
  // ═══════════════ サイト依存情報(サイトが変わったらここだけ直す) ═══════════════

  // 画面に実際に見えているか。幅・高さ0 / display:none の要素(別タブにある「ソースを追加」など)を
  // 誤って掴まないための判定。
  const isVisible = (e) => {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    const s = getComputedStyle(e);
    return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
  };
  const firstVisible = (list) => list.find(isVisible) || null;
  const buttons = () => [...document.querySelectorAll("button")];

  // ── 裏タブ対策。非表示のタブでは document が「hidden」になり、requestAnimationFrame が止まる。
  //    Angular/Material の画面更新(入力→ボタン有効化、ダイアログ表示など)がそれに依存していると、値を入れても反映されない。
  //    そこで「常に表示中」と見せかけ、rAF は setTimeout で代替する(フォアグラウンドで使っても害はない)。
  if (!window.__nblWake) {
    window.__nblWake = true;
    try {
      Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" });
      Object.defineProperty(document, "hidden", { configurable: true, get: () => false });
      window.requestAnimationFrame = (cb) => setTimeout(() => cb(performance.now()), 16);
      window.cancelAnimationFrame = (id) => clearTimeout(id);
      document.dispatchEvent(new Event("visibilitychange"));
    } catch { /* 失敗しても本処理は続ける */ }
  }

  // ── 「本物の入力/クリック」の依頼口。拡張(background.js)が window.__nblTrusted=true にしたときだけ使う。
  //    スクリプトの click() や value 代入では反応しない/反映されない箇所があるため、CDP の Input.* で実行してもらう。
  //    依頼は window.__nblNeedClick / window.__nblNeedType に seq 付きで出し、background が1回だけ処理する。
  //    手動(コンソール)実行など __nblTrusted が無いときは、従来どおりスクリプトで実行する。
  let reqSeq = 0;
  async function pressEl(el, waitMs = 6000) {
    if (!window.__nblTrusted) { el.click(); return "script"; }
    el.scrollIntoView?.({ block: "center" });
    await sleep(200);
    const r = el.getBoundingClientRect();
    const hit = document.elementFromPoint(Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2));
    if (!hit || !(hit === el || el.contains(hit))) { el.click(); return "script-covered"; } // 別の要素(ダイアログの幕など)に覆われていると、本物のクリックは別物を押してしまう
    let clicked = false;
    const on = (e) => { if (e.isTrusted) clicked = true; };
    el.addEventListener("click", on, true);
    window.__nblNeedClick = { x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2), width: Math.round(r.width), height: Math.round(r.height), clickable: true, seq: ++reqSeq, kind: "press" };
    const ok = await waitFor(() => clicked, waitMs, 100);
    delete window.__nblNeedClick;
    el.removeEventListener("click", on, true);
    if (!ok) { el.click(); return "script-fallback"; } // 本物のクリックが届かなかったら、せめてスクリプトで押す
    return "trusted";
  }
  async function typeInto(el, text) {
    el.focus();
    await sleep(150);
    if (window.__nblTrusted) {
      el.select?.();
      window.__nblNeedType = { seq: ++reqSeq, text };
      const ok = await waitFor(() => el.value === text, 8000, 100);
      delete window.__nblNeedType;
      if (ok) return "trusted";
    }
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value").set.call(el, text);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    return "script";
  }
  // 失敗時の状況スナップショット(通知・ポップアップの詳細に載せる。原因調査用)
  const snap = () => JSON.stringify({
    vis: document.visibilityState,
    dialogs: [...document.querySelectorAll("mat-dialog-container")].map((d) => (d.innerText || "").replace(/\s+/g, " ").slice(0, 80)),
    buttons: [...document.querySelectorAll("button")].filter((b) => b.getBoundingClientRect().width > 0).slice(0, 14).map((b) => b.getAttribute("aria-label") || (b.innerText || "").trim().slice(0, 10)),
  });

  const SITE = {
    // aria-label で探すのは、狭い幅だとボタンの文字(innerText)が消えて「add_2」だけになるため。
    addSourceButton: () => firstVisible([...document.querySelectorAll('button[aria-label="ソースを追加"]')]),
    // ダイアログ内のボタンは aria-label が無いので文言で探す。
    uploadFileButton: () => firstVisible(buttons().filter((b) => /ファイルをアップロード/.test(b.innerText || ""))),
    closeDialogButton: () => firstVisible([...document.querySelectorAll('button[aria-label="閉じる"]')]),
    // レイアウトA: ソースパネルの開閉。畳まれている間は「開く」だけが存在する。
    openPanelButton: () => document.querySelector('button[aria-label="ソースパネルを開く"]'),
    closePanelButton: () => document.querySelector('button[aria-label="ソースパネルを閉じる"]'),
    // レイアウトB: 上部のタブ(Sources / チャット / Studio)。
    tabButtons: () => [...document.querySelectorAll(".tabs-slider-container button.tab-button")],
    tabText: (b) => (b.innerText || "").trim(),
    isTabActive: (b) => b.classList.contains("tab-button--active"),
    sourcesTabPattern: /^(Sources|ソース)$/,
    // ソース一覧。各行の aria-label がファイル名。
    sourceItems: () => [...document.querySelectorAll(".source-stretched-button")],
    sourceName: (el) => el.getAttribute("aria-label"),
    errorIcons: () => [...document.querySelectorAll('[aria-label="エラー情報"]')],
    // ── 同名ソースの削除(実機で確認した構造: 行 → 「もっと見る」→ メニュー「ソースを削除」→ 確認ダイアログ「削除」)
    sourceRows: () => [...document.querySelectorAll(".single-source-container")],
    rowName: (row) => row.querySelector(".source-stretched-button")?.getAttribute("aria-label"),
    rowMenuButton: (row) => row.querySelector('button[aria-label="もっと見る"]'),
    openMenuItems: () => [...document.querySelectorAll("button.mat-mdc-menu-item")],
    deleteMenuPattern: /ソースを削除/,
    confirmDialogs: () => [...document.querySelectorAll("mat-dialog-container")],
    confirmButton: (dlg) => [...dlg.querySelectorAll("button")].find((b) => (b.innerText || "").trim() === "削除"),
  };
  // 実行前チェック。見つからなければ、SITE のどこを直すかを示して止まる。
  // (見えているかは問わない。別タブ/畳まれたパネルのせいで隠れていることがあるため)
  const PRECHECK = {
    'SITE.addSourceButton(aria-label="ソースを追加")': () => document.querySelector('button[aria-label="ソースを追加"]'),
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const waitFor = async (fn, ms = 5000, step = 250) => {
    for (let t = 0; t < ms; t += step) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  };

  // ═══════════════ ページオブジェクト ═══════════════

  /** ソース一覧。表示の確保と元に戻す処理を担当する。 */
  class SourcePanel {
    #undo = []; // 元に戻す処理を、変更した順に積む(restore で逆順に実行)

    /** 「ソースを追加」ボタンとソース一覧が【見える】状態にする。 */
    async ensureVisible() {
      // レイアウトB: Sources 以外のタブにいたら切り替える。
      const tab = SITE.tabButtons().find((b) => SITE.sourcesTabPattern.test(SITE.tabText(b)));
      if (tab && !SITE.isTabActive(tab)) {
        const prev = SITE.tabButtons().find(SITE.isTabActive);
        tab.click();
        if (prev) this.#undo.push(() => prev.click());
        await waitFor(() => SITE.addSourceButton(), 3000);
      }
      // レイアウトA: 畳まれたソースパネルを開く。畳んだ状態でも「ソースを追加」は見えるが一覧は消える。
      // 一覧が無いと「追加できたか」を確認できないので、ボタンが見えていても開く。
      const open = SITE.openPanelButton();
      if (open) {
        open.click();
        this.#undo.push(() => SITE.closePanelButton()?.click());
        await waitFor(() => SITE.closePanelButton(), 3000);
      }
      await sleep(400); // 開閉アニメーションが落ち着くのを待つ
      if (!SITE.addSourceButton())
        throw new Error("【SITE.addSourceButton / SITE.tabButtons / SITE.openPanelButton】「ソースを追加」ボタンを表示できません");
    }

    async restore() {
      for (const f of this.#undo.reverse()) {
        try { f(); } catch { /* 戻せなくても本処理の結果は変えない */ }
        await sleep(300);
      }
      this.#undo = [];
    }

    /** 現在の同名の行(DOM要素)を返す。登録【前】に呼んで「古い行」を覚えておくのに使う。 */
    rowsNamed(name) { return SITE.sourceRows().filter((r) => SITE.rowName(r) === name); }

    /**
     * 登録【後】に、古い同名ソースだけを消す(足してから消す=途中で中断しても元が残る)。
     * 古い行の見分け方: 登録前に覚えた行の DOM 要素がまだ画面にあればそれを消す。
     * 再描画で要素が作り直されていたら、「同名の先頭から oldCount 件」を消す(新しい行は末尾に足される前提)。
     * 戻り値: 消した件数。
     */
    async deleteOld(name, oldRows) {
      let deleted = 0;
      const stillThere = oldRows.filter((r) => r.isConnected && SITE.rowName(r) === name);
      if (stillThere.length === oldRows.length) {
        for (const r of stillThere) { await this.#deleteRow(r, name); deleted++; }
      } else {
        for (let i = 0; i < oldRows.length; i++) {
          const r = this.rowsNamed(name)[0];
          if (!r || this.rowsNamed(name).length <= 1) break; // 新しい行まで消さない
          await this.#deleteRow(r, name); deleted++;
        }
      }
      return deleted;
    }

    /** 1行を削除する: 行のメニュー →「ソースを削除」→ 確認ダイアログ「削除」。 */
    async #deleteRow(row, name) {
      // 前のメニューが開きっぱなしだと別行のメニューを誤操作するので、先に閉じる
      if (document.querySelector(".mat-mdc-menu-panel")) {
        document.querySelector(".cdk-overlay-backdrop")?.click();
        await waitFor(() => !document.querySelector(".mat-mdc-menu-panel"), 2000);
      }
      SITE.rowMenuButton(row)?.click();
      const item = await waitFor(() => SITE.openMenuItems().find((b) => SITE.deleteMenuPattern.test(b.textContent)), 3000);
      if (!item) throw new Error("【SITE.rowMenuButton / SITE.deleteMenuPattern】削除メニューが開きません");
      item.click();
      const dlg = await waitFor(() => SITE.confirmDialogs().find((d) => SITE.confirmButton(d)), 3000);
      if (!dlg) throw new Error("【SITE.confirmDialogs / SITE.confirmButton】削除の確認ダイアログが出ません");
      if (!(dlg.innerText || "").includes(name)) {
        [...dlg.querySelectorAll("button")].find((b) => (b.innerText || "").trim() === "キャンセル")?.click();
        throw new Error("確認ダイアログの対象名が一致しないため削除を中止しました");
      }
      const n = this.rowsNamed(name).length;
      SITE.confirmButton(dlg).click();
      const gone = await waitFor(() => this.rowsNamed(name).length < n, 10000);
      if (!gone) throw new Error("削除が反映されませんでした: " + name);
      await sleep(500);
    }

    names() { return SITE.sourceItems().map(SITE.sourceName); }
    errorCount() { return SITE.errorIcons().length; }
    #count(arr, n) { return arr.filter((x) => x === n).length; }

    /** 追加前(before)より、指定ファイル名の行が増えるまで待つ(同名があっても個数で判定する)。 */
    async waitForAdded(expectedNames, before, timeoutMs) {
      const t0 = Date.now();
      while (Date.now() - t0 < timeoutMs) {
        const now = this.names();
        const added = expectedNames.filter((n) => this.#count(now, n) > this.#count(before, n));
        if (added.length === expectedNames.length) return added;
        await sleep(1000);
      }
      return null;
    }
  }

  /** 「ソースを追加」ダイアログ。 */
  class AddSourceDialog {
    async open() {
      if (SITE.uploadFileButton()) return; // 既に開いている(?addSource=true で開いた場合など)
      const add = SITE.addSourceButton();
      if (!add) throw new Error("【SITE.addSourceButton】「ソースを追加」ボタンが見つかりません");
      add.click(); // このボタンはスクリプトの click() でダイアログが開く(確認済み)
      if (!(await waitFor(() => SITE.uploadFileButton())))
        throw new Error("【SITE.uploadFileButton】「ファイルをアップロード」ボタンが見つかりません");
    }

    async close() {
      SITE.closeDialogButton()?.click();
      await sleep(600);
    }

    /**
     * ボタンの中心座標と、他の要素に隠れていないか(=本物のクリックが届くか)。
     * 狭い幅ではダイアログが下からせり上がるので、位置が止まるまで待ってから測る
     * (動いている最中の座標を渡すと、隣のボタン=「Fast Research」メニューなどを押してしまう)。
     */
    async uploadButtonInfo() {
      let btn = SITE.uploadFileButton();
      if (!btn) return null;
      let last = "";
      for (let i = 0; i < 20; i++) {
        btn = SITE.uploadFileButton() || btn;
        const r = btn.getBoundingClientRect();
        const now = [r.x, r.y, r.width, r.height].map(Math.round).join(",");
        if (now === last) break; // 連続して同じ位置なら止まったとみなす
        last = now;
        await sleep(150);
      }
      const r = btn.getBoundingClientRect();
      const x = Math.round(r.x + r.width / 2);
      const y = Math.round(r.y + r.height / 2);
      const hit = document.elementFromPoint(x, y); // その座標で最前面にある要素
      return { x, y, width: Math.round(r.width), height: Math.round(r.height), clickable: !!hit && (btn === hit || btn.contains(hit)) };
    }

    /**
     * 「ファイルをアップロード」を押させて、ファイル入力が呼ばれる(isFired)まで待つ。
     * 戻り値: "script" | "trusted-click" | null(時間切れ)
     */
    async pressUpload(isFired, clickWaitMs) {
      const btn = SITE.uploadFileButton();
      // まずスクリプトの click() を一度だけ試す。現状のサイトでは通らないが、将来通るようになれば
      // 外部クリックが不要になるので残している(通らなければ 1.5 秒で見切る)。
      btn.click();
      if (await waitFor(isFired, 1500, 100)) return "script";

      // 通らなければ、本物のクリックを待つ。座標を公開し、見た目にも枠で目印を付ける。
      const info = await this.uploadButtonInfo();
      const prevOutline = btn.style.outline;
      const prevOffset = btn.style.outlineOffset;
      btn.style.outline = "3px solid #ff9800";
      btn.style.outlineOffset = "3px";
      window.__nblNeedClick = info; // ← background.js はこれを読んで CDP でクリックする
      try {
        return (await waitFor(isFired, clickWaitMs, 200)) ? "trusted-click" : null;
      } finally {
        btn.style.outline = prevOutline;
        btn.style.outlineOffset = prevOffset;
        delete window.__nblNeedClick;
      }
    }
  }

  /**
   * アプリが内部で作る <input type=file> の click() を【一度だけ】乗っ取り、File を流し込む。
   * 使い終わったら(失敗しても)必ず元に戻す(disarm)。ページ全体の click を壊さないため。
   */
  class FileChooserIntercept {
    fired = false;
    arm(files) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      const proto = HTMLInputElement.prototype;
      const orig = proto.click;
      const self = this;
      this.fired = false;
      this.disarm = () => { proto.click = orig; };
      proto.click = function () {
        if (this.type === "file" && !self.fired) {
          self.fired = true;
          self.disarm(); // 一度使ったらすぐ元に戻す
          this.files = dt.files; // OS のダイアログを開かず、ここで選択済みにする
          this.dispatchEvent(new Event("input", { bubbles: true }));
          this.dispatchEvent(new Event("change", { bubbles: true }));
          return;
        }
        return orig.apply(this, arguments); // それ以外の click は通常どおり
      };
    }
  }

  // ═══════════════ 手順書 ═══════════════
  async function uploadFiles(files, override = {}) {
    const CFG = { waitMs: 60000, clickWaitMs: 60000, dryRun: false, replaceSameName: true, ...override };

    const broken = Object.entries(PRECHECK).filter(([, f]) => !f()).map(([n]) => n);
    if (broken.length)
      throw new Error("サイト構造が変わった可能性: SITE の次の項目を直してください → " + broken.join(", "));
    if (!CFG.dryRun && !(files && files.length)) throw new Error("アップロードするファイルがありません");

    const panel = new SourcePanel();
    const dialog = new AddSourceDialog();
    const chooser = new FileChooserIntercept();

    try {
      await panel.ensureVisible();
      await waitIdle({ allowOverlays: true }); // 前の作業の更新が落ち着くまで待ってから始める(allowOverlays: ?addSource=true のダイアログは許容)
      // 置き換え用に、登録【前】にある同名の行を覚えておく(登録が成功してから消す)
      const oldRows = new Map();
      if (CFG.replaceSameName && !CFG.dryRun)
        for (const n of new Set((files || []).map((f) => f.name))) oldRows.set(n, panel.rowsNamed(n));
      const before = panel.names();
      await dialog.open();

      // dryRun: ボタンまで届き、本物のクリックが当たる状態かだけ確認して閉じる
      if (CFG.dryRun) {
        const info = await dialog.uploadButtonInfo();
        await dialog.close();
        return { ok: !!info?.clickable, dryRun: true, uploadButton: info };
      }

      chooser.arm(files); // ボタンが押される【前】に仕掛ける
      const how = await dialog.pressUpload(() => chooser.fired, CFG.clickWaitMs);
      if (!how) return { ok: false, reason: "「ファイルをアップロード」がクリックされませんでした(時間切れ)" };

      const names = files.map((f) => f.name);
      const added = await panel.waitForAdded(names, before, CFG.waitMs);
      if (!added) return { ok: false, reason: "一覧に追加されませんでした", before, after: panel.names() };
      // 登録に成功したので、古い同名ソースを消す。失敗しても登録自体は成功扱い(重複が残るだけ)
      let replaced = 0, deleteError = null;
      for (const [n, rows] of oldRows) {
        if (!rows.length) continue;
        try { replaced += await panel.deleteOld(n, rows); } catch (e) { deleteError = String((e && e.message) || e); break; }
      }
      await sleep(3000); // 処理エラーのアイコンはアップロード直後に出ることがあるので少し待つ
      return { ok: true, added, clickedBy: how, errorIconCount: panel.errorCount(), replaced, deleteError };
    } finally {
      chooser.disarm?.();    // 乗っ取りは必ず解除
      await panel.restore(); // タブ・パネルの状態を元に戻す
    }
  }


  // ═══════════════ Studio: スライド資料の生成 → ダウンロード ═══════════════
  // 実機で確認した構造(2026-10):
  //   Studio のボタン  div.create-artifact-button-container[aria-label="スライド資料"]
  //   設定ダイアログ   mat-dialog-container に「スライド資料をカスタマイズ」…「生成」ボタン(既定値のまま押す)
  //   生成物の一覧     artifact-library-item(新しいものが先頭)。生成中は mat-icon が "progress_activity"、
  //                    タイトルが「…を生成しています...」。完成するとアイコンが "tablet" に変わりタイトルが内容名になる
  //   ダウンロード     行の button[aria-label="その他"] → メニューに「PowerPoint（.pptx）をダウンロード」「PDF ドキュメント（.pdf）をダウンロード」
  // ※ 生成には5〜10分かかる。完成の判定は10秒ごと(cfg.pollMs)。
  const STUDIO = {
    openPanelButton: () => document.querySelector('button[aria-label="Studio パネルを開く"]'),
    slideButton: () => [...document.querySelectorAll(".create-artifact-button-container")].find((e) => e.getAttribute("aria-label") === "スライド資料" && e.offsetParent),
    dialogs: () => [...document.querySelectorAll("mat-dialog-container")],
    generateButton: (dlg) => [...dlg.querySelectorAll("button")].find((b) => (b.innerText || "").trim() === "生成"),
    items: () => [...document.querySelectorAll("artifact-library-item")],
    itemIcon: (it) => (it.querySelector("mat-icon")?.textContent || "").trim(),
    itemTitle: (it) => (it.querySelector(".artifact-title")?.textContent || "").trim(),
    itemDetail: (it) => (it.querySelector(".artifact-details")?.textContent || "").replace(/\s+/g, " ").trim(),
    busyIcon: "progress_activity",
    errorPattern: /エラー|失敗|生成できません/,
    itemMenuButton: (it) => it.querySelector('button[aria-label="その他"]'),
    menuItems: () => [...document.querySelectorAll("button.mat-mdc-menu-item")],
    downloadPattern: { pptx: /PowerPoint/, pdf: /PDF/ },
  };

  async function generateSlides(override = {}) {
    const CFG = { pollMs: 10000, timeoutMs: 20 * 60000, format: "pptx", startWaitMs: 45000, ...override };
    const panelUndo = [];
    try {
      // レイアウトB(狭い): Studio はタブ。レイアウトA(広い): 右パネルが畳まれていたら開く
      const tab = SITE.tabButtons().find((b) => /Studio/.test(SITE.tabText(b)));
      if (tab && !SITE.isTabActive(tab)) {
        const prev = SITE.tabButtons().find(SITE.isTabActive);
        tab.click();
        if (prev) panelUndo.push(() => prev.click());
      }
      const open = STUDIO.openPanelButton();
      if (open) open.click();
      if (!(await waitFor(() => STUDIO.slideButton(), 5000)))
        return { ok: false, reason: "【STUDIO.slideButton】「スライド資料」ボタンが見つかりません" };
      await waitIdle(); // ソースの取り込み中に押すと設定ダイアログが出ない(実機の失敗例)ので、落ち着くまで待つ

      const beforeItems = new Set(STUDIO.items());
      const beforeTitles = new Set(STUDIO.items().map(STUDIO.itemTitle)); // 画面の再描画で古い行が「新しい要素」に見えても、タイトルで見分ける
      // 押してもダイアログが出なければ、落ち着くのを待って押し直す(最大4回)
      let dlg = null;
      for (let attempt = 0; attempt < 4 && !dlg; attempt++) {
        if (attempt) await waitIdle({ timeoutMs: 30000 });
        if (!STUDIO.slideButton()) break;
        await pressEl(STUDIO.slideButton());
        dlg = await waitFor(() => STUDIO.dialogs().find((d) => STUDIO.generateButton(d)), 6000);
      }
      if (!dlg) return { ok: false, reason: "【STUDIO.dialogs / generateButton】スライドの設定ダイアログが出ません " + snap() };
      await sleep(500);
      await pressEl(STUDIO.generateButton(dlg));

      // 生成中の行が現れるのを待つ(新しい行 = 開始前の一覧に無かったもの)
      // 新しい行 = 生成中のアイコンが付いている行、または開始前に無かったタイトルの行(再描画で古い完成済みの行を取り違えない)
      const isNew = (it) => STUDIO.itemIcon(it) === STUDIO.busyIcon || (!beforeItems.has(it) && !beforeTitles.has(STUDIO.itemTitle(it)));
      const busy = await waitFor(() => STUDIO.items().find(isNew), CFG.startWaitMs, 500);
      if (!busy) return { ok: false, reason: "生成が始まりませんでした(上限に達している可能性) " + snap() };
      let item = busy;
      const t0 = Date.now();
      let last = "";
      // 10秒ごとに完成を確認する
      while (Date.now() - t0 < CFG.timeoutMs) {
        await sleep(CFG.pollMs);
        if (!item.isConnected) item = STUDIO.items()[0]; // 再描画で差し替わったら先頭の行を追う
        if (!item) continue;
        last = STUDIO.itemTitle(item) + " / " + STUDIO.itemDetail(item);
        window.__nblSlidesProgress = last;
        if (STUDIO.itemIcon(item) === STUDIO.busyIcon) continue;
        if (STUDIO.errorPattern.test(last)) return { ok: false, reason: "生成に失敗した可能性: " + last };
        break;
      }
      if (STUDIO.itemIcon(item) === STUDIO.busyIcon) return { ok: false, reason: "時間内に生成が終わりませんでした: " + last };

      // ダウンロード: 行のメニュー → 形式を選ぶ
      const title = STUDIO.itemTitle(item);
      if (document.querySelector(".mat-mdc-menu-panel")) { document.querySelector(".cdk-overlay-backdrop")?.click(); await sleep(400); }
      { const mb = STUDIO.itemMenuButton(item); if (mb) await pressEl(mb); } // 本物のクリック(スクリプトのclickだと「ポップアップがブロックされました」になることがある)
      const pat = STUDIO.downloadPattern[CFG.format] || STUDIO.downloadPattern.pptx;
      const dl = await waitFor(() => STUDIO.menuItems().find((b) => pat.test(b.textContent)), 4000);
      if (!dl) return { ok: false, reason: "【STUDIO.itemMenuButton / downloadPattern】ダウンロード項目が見つかりません", title };
      await pressEl(dl); // ダウンロード開始。本物のクリックにしてポップアップのブロックを避ける。保存先はブラウザの設定に従う
      await sleep(2000);
      return { ok: true, title, format: CFG.format, elapsedMs: Date.now() - t0 };
    } finally {
      for (const f of panelUndo.reverse()) { try { f(); } catch {} await sleep(300); }
    }
  }
  window.__nblGenerateSlides = generateSlides;

  // ═══════════════ Studio 汎用: 任意の種類を、指示文とオプション付きで生成 → 完成待ち → ダウンロード ═══════════════
  // 実機で確認した各ダイアログ(2026-10)。ボタン = .create-artifact-button-container[aria-label=…]
  //   音声解説      形式[詳細/概要/評論/議論](ラジオ) 長さ[短め/デフォルト] 言語 / 自由入力 textarea
  //   スライド資料  (既定で生成できる。自由入力あり)
  //   動画解説      形式[概要/説明動画] 言語 / 自由入力「独自のトピックを入力してください」(「カスタム トピック」を押すと出る場合あり)
  //   マインドマップ 言語 / 自由入力のみ
  //   レポート      形式[インタラクティブ/ドキュメント] + テンプレートのカード(概要説明資料/学習ガイド/ブログ投稿/独自に作成/推奨…)。自由入力欄は無い
  //   フラッシュカード 枚数[少なめ/標準/多め] 難易度[簡単/標準/難しい] 画像[含める/テキストのみ] / 自由入力
  //   クイズ        質問数 難易度 画像 質問タイプ[多肢選択/複数選択/空欄を埋めて/記述式] / 自由入力
  //   インフォグラフィック 言語 レイアウト[横向き/縦向き/正方形] ビジュアルスタイル(ラジオ11個。先頭が「自動選択」) 詳細レベル[簡潔/標準/詳細] / 自由入力
  //   Data Table    言語 / 自由入力のみ
  //   共通: 下に [後で生成][生成]。完成した行のメニュー「その他」に「ダウンロード」がある(インフォグラフィックで確認済み。他の種類は種類ごとに異なる可能性)。
  // オプションの指定: options = { "グループ見出し": "選ぶ文字" }(例 { "レイアウトを選択": "縦向き", "詳細レベル": "簡潔" })。
  //   見出しの文字を探し、その近くの選択肢(ラジオ/トグル/ボタン)から、文字が一致するものを押す。見出しなしで { "": "縦向き" } も可(ダイアログ全体から探す)。
  const STUDIO_KINDS = {
    audio: "音声解説", slides: "スライド資料", video: "動画解説", mindmap: "マインドマップ", report: "レポート",
    flashcards: "フラッシュ カード", quiz: "クイズ", infographic: "インフォグラフィック", datatable: "Data Table",
  };
  const STUDIO_X = {
    kindButton: (label) => [...document.querySelectorAll(".create-artifact-button-container")].find((e) => e.getAttribute("aria-label") === label && e.offsetParent),
    dialog: () => [...document.querySelectorAll("mat-dialog-container")].find((d) => STUDIO.generateButton(d)),
    choices: (root) => [...root.querySelectorAll('button[role=radio], mat-radio-button, [role=radio], mat-chip-option, .mat-mdc-card, button')]
      .filter((e) => isVisible(e) || e.matches("mat-radio-button")),
    textOf: (e) => (e.innerText || e.textContent || "").replace(/\bcheck\b|\bedit\b/g, " ").replace(/\s+/g, " ").trim(),
    styleRadios: (dlg) => [...dlg.querySelectorAll("mat-radio-button.carousel-radio-button")],
    textarea: (dlg) => [...dlg.querySelectorAll("textarea")].find(isVisible),
  };
  // グループ見出しを探し、その近くの選択肢から value に一致するものを返す
  function studioFindChoice(dlg, group, value) {
    const norm = (t) => t.replace(/\s+/g, " ").trim();
    let root = dlg;
    if (group) {
      const head = [...dlg.querySelectorAll("*")].find((e) => e.children.length === 0 && norm(e.textContent) === group)
        || [...dlg.querySelectorAll("*")].find((e) => norm([...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join("")) === group);
      if (!head) return { err: "見出し「" + group + "」が見つかりません" };
      root = head.parentElement;
      for (let i = 0; i < 4 && root && STUDIO_X.choices(root).length < 2; i++) root = root.parentElement;
      if (!root) return { err: "見出し「" + group + "」の選択肢が見つかりません" };
    }
    const cands = STUDIO_X.choices(root).filter((e) => !/^(ダイアログを閉じる|閉じる|後で生成|生成)$/.test(STUDIO_X.textOf(e)));
    // 同じ文字を持つ入れ子の要素(ラジオとその中のボタン等)は、いちばん外側だけにする
    const hit = cands.filter((e) => { const t = STUDIO_X.textOf(e); return t === value || t.startsWith(value + " ") || t.startsWith(value + "（"); });
    const outer = hit.filter((e) => !hit.some((o) => o !== e && o.contains(e)));
    if (!outer.length) return { err: "「" + (group ? group + " > " : "") + value + "」が見つかりません(候補: " + cands.map(STUDIO_X.textOf).slice(0, 12).join(" / ") + ")" };
    return { el: outer[0] };
  }

  // ── ソースの選択(Studio の生成対象になる)。実機で確認した構造(2026-10):
  //    見出しの「すべて選択」= mat-checkbox.select-checkbox-all-sources の input[aria-label="すべてのソースを選択"]
  //    各行 = .single-source-container の mat-checkbox.select-checkbox の input(aria-label はソース名)
  //    一覧は全件が DOM にある(仮想スクロールではない)。「一番下」= DOM の最後の行(並び順は画面の並べ替えに従う)。
  //    選択は通知ではなくノートブックの状態として残るので、生成を始めたら元の選択に戻す(restoreSources)。
  const SRC = {
    allBox: () => document.querySelector("mat-checkbox.select-checkbox-all-sources"),
    rowBoxes: () => [...document.querySelectorAll(".single-source-container mat-checkbox.select-checkbox")],
    isOn: (cb) => !!cb.querySelector("input")?.checked,
  };
  async function selectOnlyLastSource() {
    const boxes = SRC.rowBoxes();
    if (!boxes.length) throw new Error("【SRC.rowBoxes】ソースの選択ボックスが見つかりません");
    const orig = boxes.map(SRC.isOn);
    // すべて外す: 「すべて選択」を押す。一部だけ選択中だと1回目は「全選択」になるので、全部外れるまで繰り返す(最大4回)
    for (let i = 0; i < 4 && SRC.rowBoxes().some(SRC.isOn); i++) {
      const all = SRC.allBox();
      if (!all) throw new Error("【SRC.allBox】「すべて選択」が見つかりません");
      await pressEl(all.querySelector("label") || all);
      await sleep(600);
    }
    if (SRC.rowBoxes().some(SRC.isOn)) throw new Error("ソースの選択をすべて外せませんでした");
    const last = SRC.rowBoxes().at(-1);
    last.scrollIntoView({ block: "center" });
    await sleep(300);
    await pressEl(last.querySelector("label") || last);
    await sleep(600);
    const on = SRC.rowBoxes().filter(SRC.isOn);
    if (on.length !== 1 || on[0] !== SRC.rowBoxes().at(-1)) throw new Error("一番下のソースだけを選択できませんでした(選択中: " + on.length + "件)");
    const name = last.closest(".single-source-container")?.querySelector(".source-stretched-button")?.getAttribute("aria-label") || "";
    return { orig, name };
  }
  async function restoreSourceSelection(orig) {
    const boxes = SRC.rowBoxes();
    if (boxes.length !== orig.length) return { ok: false, note: "ソースの件数が変わったため、選択は元に戻していません" };
    if (orig.every(Boolean)) { // 全部オンだった → 「すべて選択」を押す(いまは1件だけオン)
      if (!SRC.rowBoxes().every(SRC.isOn)) { await pressEl(SRC.allBox().querySelector("label") || SRC.allBox()); await sleep(600); }
    } else {
      for (let i = 0; i < boxes.length; i++) {
        const cur = SRC.rowBoxes()[i];
        if (SRC.isOn(cur) !== orig[i]) { cur.scrollIntoView({ block: "center" }); await pressEl(cur.querySelector("label") || cur); await sleep(250); }
      }
    }
    const now = SRC.rowBoxes().map(SRC.isOn);
    return now.every((v, i) => v === orig[i]) ? { ok: true } : { ok: false, note: "ソースの選択を完全には元に戻せませんでした" };
  }

  /** 中断で選択が残ったとき用。保存しておいた「元の選択」を、ソース一覧の名前が同じ場合だけ戻す。 */
  async function restoreSourcesTask(task) {
    const panel = new SourcePanel();
    try {
      await panel.ensureVisible();
      await sleep(800);
      const names = SITE.sourceItems().map(SITE.sourceName);
      const want = task.names || [];
      if (names.length !== want.length || names.some((n, i) => n !== want[i]))
        return { ok: true, skipped: true, summary: "ソース一覧が変わっているため、選択は戻していません" };
      const r = await restoreSourceSelection(task.orig || []);
      return r.ok ? { ok: true, summary: "ソースの選択を元に戻しました" } : { ok: false, reason: r.note };
    } finally { await panel.restore(); }
  }

  async function generateStudio(task = {}) {
    const CFG = { pollMs: 10000, startWaitMs: 45000, ...task };
    const label = STUDIO_KINDS[CFG.kind];
    if (!label) return { ok: false, reason: "未知の種類: " + CFG.kind };
    const timeoutMs = CFG.timeoutMs || ({ audio: 40, video: 45 }[CFG.kind] || 25) * 60000;
    const panelUndo = [];
    let srcInfo = null, srcRestored = false, srcNote = "";
    // 選択を元に戻す(ソースパネルを見える状態にして実行し、パネルの状態も戻す)。何度呼んでも1回だけ実行する。
    const restoreSrc = async () => {
      if (!srcInfo || srcRestored || CFG.restoreSources === false) return;
      srcRestored = true;
      const panel = new SourcePanel();
      try { await panel.ensureVisible(); const r = await restoreSourceSelection(srcInfo.orig); if (!r.ok) srcNote = r.note; window.__nblSrcState = { restored: true, note: srcNote }; }
      catch (e) { srcNote = "ソースの選択を元に戻せませんでした: " + String((e && e.message) || e); }
      finally { await panel.restore(); }
    };
    const prog = (t) => { window.__nblStudioProgress = t; window.__nblEntryProgress = t; };
    try {
      // ⓪ ソースの選択(task.sources === "last": すべて外して、一番下のソースだけを選ぶ)
      if (CFG.sources === "last") {
        const panel = new SourcePanel();
        try {
          await panel.ensureVisible();
          srcInfo = await selectOnlyLastSource();
          // 拡張が保存できるように「元の選択」を公開する(途中で止まっても、次回の起動時に戻せる)
          window.__nblSrcState = { orig: srcInfo.orig, names: SITE.sourceItems().map(SITE.sourceName), restored: false };
        }
        catch (e) { return { ok: false, reason: "ソースの選択: " + String((e && e.message) || e) }; }
        finally { await panel.restore(); }
      }
      const tab = SITE.tabButtons().find((b) => /Studio/.test(SITE.tabText(b)));
      if (tab && !SITE.isTabActive(tab)) {
        const prev = SITE.tabButtons().find(SITE.isTabActive);
        tab.click();
        if (prev) panelUndo.push(() => prev.click());
      }
      STUDIO.openPanelButton()?.click();
      if (!(await waitFor(() => STUDIO_X.kindButton(label), 5000)))
        return { ok: false, reason: "【STUDIO_X.kindButton】「" + label + "」ボタンが見つかりません" };
      await waitIdle();

      const beforeItems = new Set(STUDIO.items());
      const beforeTitles = new Set(STUDIO.items().map(STUDIO.itemTitle));
      const beforeBusy = new Set(STUDIO.items().filter((it) => STUDIO.itemIcon(it) === STUDIO.busyIcon).map(STUDIO.itemTitle)); // 前から生成中だった行(別の生成)は「新しい行」にしない
      let dlg = null;
      for (let attempt = 0; attempt < 4 && !dlg; attempt++) {
        if (attempt) await waitIdle({ timeoutMs: 30000 });
        const b = STUDIO_X.kindButton(label);
        if (!b) break;
        await pressEl(b);
        dlg = await waitFor(() => STUDIO_X.dialog(), 6000);
      }
      if (!dlg) return { ok: false, reason: "【STUDIO_X.dialog】" + label + " の設定ダイアログが出ません " + snap() };
      await sleep(600);

      const picked = {};
      // ① ランダムスタイル(インフォグラフィック)
      if (CFG.randomStyle) {
        const radios = STUDIO_X.styleRadios(dlg).filter((r) => CFG.randomStyleIncludeAuto || STUDIO_X.textOf(r) !== "自動選択");
        if (!radios.length) return { ok: false, reason: "【STUDIO_X.styleRadios】ビジュアルスタイルの選択肢が見つかりません" };
        const r = radios[Math.floor(Math.random() * radios.length)];
        r.scrollIntoView({ block: "nearest", inline: "center" });
        await sleep(300);
        await pressEl(r);
        picked.style = STUDIO_X.textOf(r);
        await sleep(300);
      }
      // ② オプション
      for (const [group, value] of Object.entries(CFG.options || {})) {
        const f = studioFindChoice(dlg, group, value);
        if (f.err) return { ok: false, reason: "オプション: " + f.err };
        f.el.scrollIntoView({ block: "nearest", inline: "center" });
        await sleep(200);
        await pressEl(f.el);
        picked[group || value] = value;
        await sleep(300);
      }
      // ③ 自由入力
      if (CFG.prompt) {
        let ta = STUDIO_X.textarea(dlg);
        if (!ta) { // 動画: 「カスタム トピック」を押すと入力欄が出る
          const custom = [...dlg.querySelectorAll("button")].find((b) => /カスタム トピック/.test(b.innerText || ""));
          if (custom) { await pressEl(custom); ta = await waitFor(() => STUDIO_X.textarea(dlg), 3000); }
        }
        if (!ta) return { ok: false, reason: "【STUDIO_X.textarea】" + label + " に自由入力欄がありません(この種類は指示文を入れられません)" };
        await typeInto(ta, CFG.prompt);
        await sleep(400);
      }
      if (srcInfo) { // ダイアログに出ている「N 件のソース」で、選択が反映されたかを確認する
        const m = /(\d+)\s*件のソース/.exec(dlg.innerText || "");
        picked["ソース"] = (srcInfo.name || "一番下").slice(0, 30) + (m ? "(" + m[1] + "件)" : "");
        if (m && m[1] !== "1") return { ok: false, reason: "生成対象のソースが1件になっていません(" + m[1] + "件)" };
      }
      // ④ 生成
      const gen = STUDIO.generateButton(dlg);
      if (!gen || gen.disabled) return { ok: false, reason: "「生成」ボタンが押せません(必須項目が未選択の可能性) " + snap() };
      await pressEl(gen);

      // 新しい行 = 開始前に無かったタイトルの行(生成中の行は「…を生成しています...」という新しいタイトル)。再描画で古い行の要素が入れ替わっても取り違えない
      const isNew = (it) => !beforeTitles.has(STUDIO.itemTitle(it)) || (!beforeItems.has(it) && STUDIO.itemIcon(it) === STUDIO.busyIcon && !beforeBusy.has(STUDIO.itemTitle(it)));
      const busy = await waitFor(() => STUDIO.items().find(isNew), CFG.startWaitMs, 500);
      if (!busy) return { ok: false, reason: "生成が始まりませんでした(上限に達している可能性) " + snap() };
      let item = busy;
      await restoreSrc(); // 生成の対象は押した時点で決まっている。ここで元の選択に戻す
      const t0 = Date.now();
      let last = "";
      while (Date.now() - t0 < timeoutMs) {
        await sleep(CFG.pollMs);
        if (!item.isConnected) item = STUDIO.items()[0];
        if (!item) continue;
        last = STUDIO.itemTitle(item) + " / " + STUDIO.itemDetail(item);
        prog(label + ": " + last);
        if (STUDIO.itemIcon(item) === STUDIO.busyIcon) continue;
        if (STUDIO.errorPattern.test(last)) return { ok: false, reason: "生成に失敗した可能性: " + last };
        break;
      }
      if (STUDIO.itemIcon(item) === STUDIO.busyIcon) return { ok: false, reason: "時間内に生成が終わりませんでした: " + last };
      const title = STUDIO.itemTitle(item);
      const out = { ok: true, kind: CFG.kind, label, title, picked, elapsedMs: Date.now() - t0, downloaded: false, ...(srcNote ? { srcNote } : {}) };
      if (CFG.download === false) return out;

      // ダウンロード: 行のメニュー →「ダウンロード」(スライドだけは形式を選ぶ)
      await closeOpenMenu();
      { const mb = STUDIO.itemMenuButton(item); if (mb) await pressEl(mb); } // 本物のクリック(ポップアップのブロック回避)
      const pat = CFG.kind === "slides" ? (STUDIO.downloadPattern[CFG.format] || STUDIO.downloadPattern.pptx) : /ダウンロード/;
      const dl = await waitFor(() => STUDIO.menuItems().find((b) => pat.test(b.textContent)), 4000);
      if (!dl) {
        const items = STUDIO.menuItems().map((b) => (b.textContent || "").replace(/\s+/g, " ").trim());
        await closeOpenMenu();
        return { ...out, note: "この種類にはダウンロード項目がありませんでした(メニュー: " + items.join(" / ") + ")" };
      }
      await pressEl(dl); // 本物のクリック。スクリプトの click() だと、新しいタブを開く系のダウンロードが「ポップアップがブロックされました」になる
      await sleep(2500);
      // 形式の選択メニューが続けて開いた場合に備え、先頭の項目を押す
      const sub = STUDIO.menuItems().filter((b) => b !== dl && b.isConnected);
      if (sub.length && document.querySelector(".mat-mdc-menu-panel") && !STUDIO.menuItems().some((b) => /共有|名前を変更|削除/.test(b.textContent))) {
        out.note = "ダウンロード形式の選択肢: " + sub.map((b) => (b.textContent || "").replace(/\s+/g, " ").trim()).join(" / ");
        await pressEl(sub[0]); await sleep(1500);
      }
      out.downloaded = true;
      return out;
    } finally {
      await restoreSrc(); // 途中で失敗しても、ソースの選択は元に戻す
      for (const f of panelUndo.reverse()) { try { f(); } catch {} await sleep(300); }
    }
  }
  window.__nblGenerateStudio = generateStudio;


  // ═══════════════ 「ソースを追加」ダイアログの各入口(検索 / URL / コピーしたテキスト) ═══════════════
  // 実機で確認した構造(2026-10):
  //  トップ画面  textarea[aria-label="入力されたクエリをもとにソースを検出する"](検索語)
  //              button[aria-label="ウェブ"](範囲: ウェブ/ドライブ), button[aria-label="Fast Research"](方式: Fast/Deep)
  //              button[aria-label="送信"](検索開始)
  //  ウェブサイト  ダイアログ内の「ウェブサイト」ボタン → textarea[aria-label="URL を入力"] → 「挿入」。複数URLは空白/改行区切り
  //  コピーしたテキスト  「コピーしたテキスト」ボタン → textarea[aria-label="貼り付けたテキスト"] → 「挿入」
  //  検索の結果  ダイアログは閉じ、ソースパネルに .source-discovery-completed-container が出て「インポート」「削除」ボタン。
  //              Fast は十数秒、Deep は数分。完成 = このコンテナが現れること。
  // textarea は Angular 管理なので、ネイティブの value セッター + input イベントで値を入れる。
  const ENTRY = {
    dialog: () => document.querySelector("mat-dialog-container"),
    dlgButton: (pred) => [...(document.querySelector("mat-dialog-container")?.querySelectorAll("button") || [])].find(pred),
    queryBox: () => document.querySelector('mat-dialog-container textarea[aria-label="入力されたクエリをもとにソースを検出する"]'),
    scopeButton: () => ENTRY.dlgButton((b) => b.getAttribute("aria-label") === "ウェブ" || b.getAttribute("aria-label") === "ドライブ"),
    modeButton: () => ENTRY.dlgButton((b) => /^(Fast Research|Deep Research)$/.test(b.getAttribute("aria-label") || "")),
    sendButton: () => ENTRY.dlgButton((b) => b.getAttribute("aria-label") === "送信"),
    websiteEntry: () => ENTRY.dlgButton((b) => /link_2/.test(b.innerText) && /ウェブサイト/.test(b.innerText)),
    textEntry: () => ENTRY.dlgButton((b) => /content_paste/.test(b.innerText)),
    urlBox: () => document.querySelector('mat-dialog-container textarea[aria-label="URL を入力"]'),
    textBox: () => document.querySelector('mat-dialog-container textarea[aria-label="貼り付けたテキスト"]'),
    insertButton: () => ENTRY.dlgButton((b) => (b.innerText || "").trim() === "挿入"),
    menuItem: (pat) => [...document.querySelectorAll(".mat-mdc-menu-panel button.mat-mdc-menu-item")].find((b) => pat.test(b.textContent)),
    scopeLabel: { web: /ウェブ上の最適なソース/, drive: /Google ドライブ/ },
    modeLabel: { fast: /Fast Research/, deep: /Deep Research/ },
    // 検索結果パネル
    results: () => document.querySelector(".source-discovery-completed-container"),
    discardButton: () => [...(ENTRY.results()?.querySelectorAll("button") || [])].find((b) => (b.innerText || "").trim() === "削除"),
    importButton: () => [...(ENTRY.results()?.querySelectorAll("button") || [])].find((b) => (b.innerText || "").trim() === "インポート"),
    resultTitle: () => (ENTRY.results()?.innerText || "").replace(/\s+/g, " ").slice(0, 120),
  };
  const setText = (ta, v) => {
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(ta, v);
    ta.dispatchEvent(new Event("input", { bubbles: true }));
  };
  const closeOpenMenu = async () => {
    if (document.querySelector(".mat-mdc-menu-panel")) { document.querySelector(".cdk-overlay-backdrop")?.click(); await sleep(400); }
  };
  async function chooseFromMenu(openBtn, pat, what) {
    await closeOpenMenu();
    await pressEl(openBtn);
    const it = await waitFor(() => ENTRY.menuItem(pat), 3000);
    if (!it) throw new Error("【ENTRY.menuItem】" + what + " のメニューが開きません");
    await pressEl(it);
    await sleep(500);
  }

  /**
   * task: { type:"search", query, mode:"fast"|"deep", scope:"web"|"drive", import:true }
   *     | { type:"urls", urls:[...] }
   *     | { type:"text", text }
   * 戻り値: { ok, kind, added(増えた件数), ... }  失敗は { ok:false, reason }
   */
  async function addEntry(task, override = {}) {
    if (task.type === "chat") return askChat(task.prompt, override);
    if (task.type === "restoresrc") return restoreSourcesTask(task); // 中断で残ったソース選択を元に戻す
    if (task.type === "studio") return generateStudio(task); // Studio の任意の種類(指示文・オプション・ランダムスタイル対応)
    if (task.type === "clearchat") return clearChat({ dryRun: !!task.dryRun }); // チャット履歴の削除(dryRun は確認ダイアログを開いて閉じるだけ)
    const CFG = { pollMs: 10000, searchTimeoutMs: 20 * 60000, ...override };
    const panel = new SourcePanel();
    const dialog = new AddSourceDialog();
    try {
      await panel.ensureVisible();
      await waitIdle({ allowOverlays: true });
      const beforeCount = SITE.sourceItems().length;
      await dialog.open();
      await sleep(400);

      if (task.type === "urls" || task.type === "text") {
        const isUrl = task.type === "urls";
        const entryBtn = await waitFor(() => (isUrl ? ENTRY.websiteEntry() : ENTRY.textEntry()), 3000);
        if (!entryBtn) return { ok: false, reason: "【ENTRY.websiteEntry / textEntry】入口ボタンが見つかりません" };
        await pressEl(entryBtn);
        const box = await waitFor(() => (isUrl ? ENTRY.urlBox() : ENTRY.textBox()), 3000);
        if (!box) return { ok: false, reason: "【ENTRY.urlBox / textBox】入力欄が見つかりません" };
        await typeInto(box, isUrl ? task.urls.join("\n") : task.text);
        const ins = await waitFor(() => { const b = ENTRY.insertButton(); return b && !b.disabled ? b : null; }, 3000);
        if (!ins) return { ok: false, reason: "「挿入」が有効になりません(入力が受理されませんでした) " + snap() };
        await pressEl(ins);
        // 行が増えるまで待つ(URLは複数同時のこともあるので1件以上増えたら成功)
        const grew = await waitFor(() => SITE.sourceItems().length > beforeCount, 30000, 500);
        if (!grew) return { ok: false, reason: "一覧に追加されませんでした" };
        await sleep(2500); // 取り込みエラーのアイコンは少し遅れて出る
        return { ok: true, kind: task.type, added: SITE.sourceItems().length - beforeCount, errorIconCount: panel.errorCount() };
      }

      if (task.type === "search") {
        // 未インポートの前回の検索結果が残っていると、検索範囲/方式のボタンが無効になる(実機で確認)。
        // 前回の失敗などで残った結果は破棄してから検索する(ダイアログを閉じた状態で操作する: 幕で隠れないように)。
        let discarded = false;
        if (ENTRY.results()) {
          if (ENTRY.dialog()) { SITE.closeDialogButton()?.click(); await sleep(700); }
          const del = ENTRY.discardButton();
          if (del) { await pressEl(del); discarded = !!(await waitFor(() => !ENTRY.results(), 6000)); }
          if (!discarded) return { ok: false, reason: "未インポートの前回の検索結果が残っています。インポートまたは削除してから再実行してください" };
          await dialog.open();
          await sleep(400);
        }
        const qb = await waitFor(() => ENTRY.queryBox(), 3000);
        if (!qb) return { ok: false, reason: "【ENTRY.queryBox】検索欄が見つかりません" };
        if (ENTRY.modeButton()?.disabled || ENTRY.scopeButton()?.disabled) return { ok: false, reason: "検索範囲/方式のボタンが無効です " + snap() };
        if (ENTRY.scopeButton() && !ENTRY.scopeButton().getAttribute("aria-label").includes(task.scope === "drive" ? "ドライブ" : "ウェブ"))
          await chooseFromMenu(ENTRY.scopeButton(), ENTRY.scopeLabel[task.scope === "drive" ? "drive" : "web"], "検索範囲");
        const wantDeep = task.mode === "deep";
        if (ENTRY.modeButton() && ENTRY.modeButton().getAttribute("aria-label").startsWith(wantDeep ? "Fast" : "Deep"))
          await chooseFromMenu(ENTRY.modeButton(), ENTRY.modeLabel[wantDeep ? "deep" : "fast"], "検索方式");
        await typeInto(ENTRY.queryBox(), task.query);
        await sleep(400);
        const send = await waitFor(() => { const b = ENTRY.sendButton(); return b && !b.disabled ? b : null; }, 3000);
        if (!send) return { ok: false, reason: "【ENTRY.sendButton】送信ボタンが有効になりません " + snap() };
        const prevResults = ENTRY.results(), prevSummary = ENTRY.resultTitle(); // 以前の検索結果が残っていても取り違えない
        await pressEl(send);

        // 完成待ち: 結果パネルが出るまで10秒ごとに確認(Fast=十数秒 / Deep=数分)
        const t0 = Date.now();
        while (Date.now() - t0 < CFG.searchTimeoutMs && !(await waitFor(() => ENTRY.results() && ENTRY.importButton() && (ENTRY.results() !== prevResults || ENTRY.resultTitle() !== prevSummary), CFG.pollMs, 500))) {
          window.__nblEntryProgress = "検索中… " + Math.round((Date.now() - t0) / 1000) + "秒";
        }
        if (!ENTRY.results() || (ENTRY.results() === prevResults && ENTRY.resultTitle() === prevSummary)) return { ok: false, reason: "時間内に検索が終わりませんでした " + snap() };
        const summary = ENTRY.resultTitle();
        if (task.import === false) return { ok: true, kind: "search", imported: false, summary };
        // パネルを開き直しても一覧が見える状態にしてからインポートし、行が増えるのを確認
        const before2 = SITE.sourceItems().length;
        await pressEl(ENTRY.importButton());
        const grew = await waitFor(() => SITE.sourceItems().length > before2, 60000, 500);
        if (!grew) return { ok: false, reason: "インポート後に一覧が増えませんでした", summary };
        await sleep(3000);
        return { ok: true, kind: "search", imported: true, added: SITE.sourceItems().length - before2, errorIconCount: panel.errorCount(), summary };
      }
      return { ok: false, reason: "未知のタスク: " + task.type };
    } finally {
      // 開いたままのダイアログを閉じる(検索送信後はアプリ側が閉じる)
      if (ENTRY.dialog()) { SITE.closeDialogButton()?.click(); await sleep(500); }
      await panel.restore();
    }
  }
  window.__nblAddEntry = addEntry;


  // ═══════════════ チャット: 質問を入力 → 回答完了を待つ → 回答テキストを取得 ═══════════════
  // 実機で確認した構造(2026-10):
  //  入力欄   textarea.query-box-input(aria-label="クエリボックス")。Angular 管理なので value セッター + input イベント
  //  送信     入力欄の近くの button[aria-label="送信"](空だと disabled)。生成中は同じ場所のボタンが
  //           button[aria-label="生成を停止"] に変わる → これが消えたら回答完了
  //  会話     .chat-message-pair(1往復)。質問 .from-user-message-inner-content / 回答 .to-user-message-inner-content
  //  回答本文  回答内の thinking-chain-view(「Thoughts」の折りたたみ)は本文ではない。
  //           引用番号は button.citation-marker(テキストは "1" など)。本文は paragraph / リスト等の要素に入る
  //  レイアウト  幅が狭い(≲700px)と Sources / チャット / Studio のタブになり、チャット以外のタブでは入力欄が非表示 → 切り替えて、終わったら戻す
  const CHAT = {
    tabPattern: /^(Chat|チャット)$/,
    inputBox: () => firstVisible([...document.querySelectorAll("textarea.query-box-input")]),
    // 入力欄から親をたどり、送信/停止ボタンを含む最小の祖先を「入力エリア」とする(ソース検索の「送信」と取り違えない)
    area: () => {
      let c = CHAT.inputBox();
      for (let i = 0; c && i < 8; i++, c = c.parentElement)
        if ([...c.querySelectorAll("button")].some((b) => ["送信", "生成を停止"].includes(b.getAttribute("aria-label")))) return c;
      return null;
    },
    sendButton: () => [...(CHAT.area()?.querySelectorAll("button") || [])].find((b) => b.getAttribute("aria-label") === "送信"),
    stopButton: () => [...(CHAT.area()?.querySelectorAll("button") || [])].find((b) => b.getAttribute("aria-label") === "生成を停止"),
    pairs: () => [...document.querySelectorAll(".chat-message-pair")],
    userEl: (pair) => pair?.querySelector(".from-user-message-inner-content"),
    answerEl: (pair) => pair?.querySelector(".to-user-message-inner-content"),
    skipInAnswer: (el) => el.matches("thinking-chain-view,.thinking-chain"),
    citation: (el) => el.matches("button.citation-marker"),
    // 回答のうち「ユーザーに見せる本文」だけを返すルート。見つからなければ回答全体
    answerBody: (ans) => ans.querySelector("labs-tailwind-doc-viewer, .message-text-content") || ans,
  };

  /** 回答の要素 → 整形テキスト。引用ボタンは [n]、考え中の折りたたみは除外、ブロック要素の終わりで改行、リストは「- 」。 */
  function answerToText(root) {
    const out = [];
    const walk = (n) => {
      if (n.nodeType === 3) { out.push(n.nodeValue); return; }
      if (n.nodeType !== 1 || CHAT.skipInAnswer(n)) return;
      if (CHAT.citation(n)) { if (/^\d+$/.test(n.textContent.trim())) out.push("[" + n.textContent.trim() + "]"); return; }
      const d = getComputedStyle(n).display;
      const block = /^(block|flex|grid|list-item|table|table-row|flow-root)$/.test(d);
      if (d === "list-item") out.push("- ");
      for (const c of n.childNodes) walk(c);
      if (block) out.push("\n");
    };
    walk(root);
    return out.join("").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }


  /**
   * 回答の要素 → Markdown。実機で確認した構造: 見出し div.paragraph.headingN / 箇条書き ul > … li.paragraph.list-item /
   * 強調 b / 引用 button.citation-marker(テキスト "1")。ほか標準タグ(strong/em/i/code/pre/a/ol/table)も扱う。
   * 引用番号は [1] の形で残す(opts.citations=false で消す)。考え中の折りたたみ(thinking-chain-view)は除外。
   */
  function answerToMarkdown(root, opts = {}) {
    const keepCites = opts.citations !== false;
    // 引用ボタンの中身は数字("1")。複数まとめた「…」アイコン(more_horiz)などは本文ではないので捨てる
    const cite = (n) => (keepCites && /^\d+$/.test(n.textContent.trim()) ? "[" + n.textContent.trim() + "]" : "");
    const inline = (n) => {
      if (n.nodeType === 3) return n.nodeValue.replace(/\s+/g, " ");
      if (n.nodeType !== 1 || CHAT.skipInAnswer(n)) return "";
      if (CHAT.citation(n)) return cite(n);
      const t = n.tagName.toLowerCase();
      if (t === "ul" || t === "ol") return ""; // 入れ子の箇条書きは、親の行とは別の行として walk で出す
      const inner = [...n.childNodes].map(inline).join("");
      if (t === "b" || t === "strong") return inner.trim() ? "**" + inner.trim() + "**" : inner;
      if (t === "i" || t === "em") return inner.trim() ? "*" + inner.trim() + "*" : inner;
      if (t === "code") return "`" + n.textContent + "`";
      if (t === "a" && n.getAttribute("href")) return "[" + inner.trim() + "](" + n.getAttribute("href") + ")";
      if (t === "br") return "\n";
      return inner;
    };
    const out = [];
    const listDepth = (el) => { let d = 0; for (let p = el.parentElement; p; p = p.parentElement) if (/^(ul|ol)$/i.test(p.tagName)) d++; return d; };
    const walk = (n) => {
      if (n.nodeType !== 1 || CHAT.skipInAnswer(n)) return;
      const t = n.tagName.toLowerCase();
      const cls = n.classList;
      const head = [...cls].map((c) => /^heading(\d)$/.exec(c)).find(Boolean);
      if (t === "pre") { out.push("\n```\n" + n.textContent.replace(/\n$/, "") + "\n```\n\n"); return; }
      if (t === "table") {
        const rows = [...n.querySelectorAll("tr")].map((r) => [...r.children].map((c) => inline(c).trim().replace(/\|/g, "\\|")));
        if (rows.length) out.push("\n| " + rows[0].join(" | ") + " |\n| " + rows[0].map(() => "---").join(" | ") + " |\n" + rows.slice(1).map((r) => "| " + r.join(" | ") + " |").join("\n") + "\n\n");
        return;
      }
      if (head) { out.push("\n" + "#".repeat(Math.min(6, Number(head[1]))) + " " + inline(n).trim() + "\n\n"); return; }
      if (t === "li" || cls.contains("list-item")) {
        const parent = n.closest("ul,ol");
        const sibs = parent ? [...parent.querySelectorAll("li")].filter((l) => l.closest("ul,ol") === parent) : [n];
        const bullet = parent && parent.tagName.toLowerCase() === "ol" ? sibs.indexOf(n) + 1 + ". " : "- ";
        out.push("  ".repeat(Math.max(0, listDepth(n) - 1)) + bullet + inline(n).trim() + "\n");
        for (const sub of [...n.querySelectorAll("ul,ol")].filter((l) => l.parentElement.closest("ul,ol") === parent)) walk(sub); // この項目の入れ子
        return;
      }
      if (t === "ul" || t === "ol") { for (const c of n.children) walk(c); if (!n.parentElement.closest("ul,ol")) out.push("\n"); return; } // 最上位のリストの後だけ空行
      if (cls.contains("paragraph")) { out.push(inline(n).trim() + "\n\n"); return; }
      for (const c of n.children) walk(c);
    };
    walk(root);
    return out.join("").replace(/\n{3,}/g, "\n\n").trim();
  }

  /**
   * prompt を送って回答を待ち、{ ok, answer, citations, elapsedMs } を返す。
   * cfg: pollMs(完了確認の間隔, 既定2秒) / timeoutMs(既定10分) / startWaitMs(送信後に新しい回答が出るまで)
   * 回答完了 = 「生成を停止」ボタンが消え、かつ回答テキストが連続2回の確認で変わらない(Deep な回答で途中停止に見える瞬間の誤判定を避ける)。
   */
  async function askChat(prompt, override = {}) {
    const CFG = { pollMs: 2000, timeoutMs: 10 * 60000, startWaitMs: 30000, ...override };
    const undo = [];
    try {
      // レイアウトB: チャットタブへ切り替え(終わったら元のタブへ)
      const tab = SITE.tabButtons().find((b) => CHAT.tabPattern.test(SITE.tabText(b)));
      if (tab && !SITE.isTabActive(tab)) {
        const prev = SITE.tabButtons().find(SITE.isTabActive);
        tab.click();
        if (prev) undo.push(() => prev.click());
      }
      // ダイアログが開いていたら閉じる(?addSource=true で開いた場合など)。入力欄を覆ってしまう
      if (document.querySelector("mat-dialog-container")) { SITE.closeDialogButton()?.click(); await sleep(600); }
      if (!(await waitFor(() => CHAT.inputBox() && CHAT.area(), 5000)))
        return { ok: false, reason: "【CHAT.inputBox / CHAT.area】チャットの入力欄が見つかりません" };
      await waitIdle();
      if (CHAT.stopButton()) return { ok: false, reason: "前の回答を生成中です" };

      // 開いた直後は過去の会話が遅れて描画される。それを「新しい回答」と取り違えないよう、
      // 会話の数が2秒変わらなくなる(履歴の描画が済む)まで待ってから送る(最大8秒)。
      let lastCount = -1, stableSince = Date.now();
      for (const t0h = Date.now(); Date.now() - t0h < 8000; await sleep(300)) {
        const n = CHAT.pairs().length;
        if (n !== lastCount) { lastCount = n; stableSince = Date.now(); }
        else if (Date.now() - stableSince >= 2000) break;
      }
      const norm = (t) => (t || "").replace(/\s+/g, " ").trim();
      const beforeSet = new Set(CHAT.pairs());
      await typeInto(CHAT.inputBox(), prompt);
      const send = await waitFor(() => { const b = CHAT.sendButton(); return b && !b.disabled ? b : null; }, 4000);
      if (!send) return { ok: false, reason: "【CHAT.sendButton】送信ボタンが有効になりません " + snap() };
      await pressEl(send);

      // 新しい会話 = 送る前に無く、質問文が今送った内容と一致するもの(過去の同じ質問とは別の要素)。再描画で差し替わっても質問文で追い直す。
      const mine = () => {
        const all = CHAT.pairs().filter((p) => norm(CHAT.userEl(p)?.textContent) === norm(prompt));
        return all.find((p) => !beforeSet.has(p)) || null;
      };
      const t0 = Date.now();
      // 質問文が表示上加工される場合に備え、8秒たっても一致しなければ「送る前に無かった最新の会話」を採用する
      const fallbackNew = () => CHAT.pairs().filter((p) => !beforeSet.has(p)).pop() || null;
      let pair = await waitFor(() => mine() || (Date.now() - t0 > 8000 ? fallbackNew() : null), CFG.startWaitMs, 300);
      if (!pair) return { ok: false, reason: "送信されませんでした(新しい会話が現れません) " + snap() };

      // 完了 = 「生成を停止」が消え、回答が空でなく、連続して変化しない。
      // 一度も生成中を見ていない場合は、取り違え防止のため送信から6秒以上たってから判定する。
      let prevText = null, stable = 0, sawStop = false;
      while (Date.now() - t0 < CFG.timeoutMs) {
        await sleep(CFG.pollMs);
        pair = mine() || (pair && pair.isConnected ? pair : fallbackNew()) || pair;
        const ans = CHAT.answerEl(pair);
        const text = ans ? answerToText(CHAT.answerBody(ans)) : "";
        window.__nblChatProgress = text.slice(-80);
        if (CHAT.stopButton()) sawStop = true;
        if (CHAT.stopButton() || !text) { stable = 0; prevText = text; continue; }
        stable = text === prevText ? stable + 1 : 0;
        prevText = text;
        if (stable >= 1 && (sawStop || Date.now() - t0 > 6000)) {
          const cites = [...CHAT.answerBody(ans).querySelectorAll("button.citation-marker")].map((b) => b.textContent.trim());
          return { ok: true, answer: text, markdown: answerToMarkdown(CHAT.answerBody(ans)), citations: [...new Set(cites)], elapsedMs: Date.now() - t0 };
        }
      }
      return { ok: false, reason: "時間内に回答が完了しませんでした", partial: prevText };
    } finally {
      for (const f of undo.reverse()) { try { f(); } catch {} await sleep(300); }
    }
  }
  window.__nblChat = askChat;


  // ═══════════════ ホーム画面(notebook.google.com/): 一覧の取得・検索・新規作成 ═══════════════
  // 実機で確認した構造(2026-10):
  //  「新しいノートブック」 button[aria-label="新しいノートブック"](ヘッダと見出し横に同名が複数 → 見えているもの)。
  //                       狭い幅でも aria-label で見つかる。押すと SPA 遷移: "/" → "/notebook/creating" → "/notebook/<uuid>"
  //  一覧の見た目は2種類(グリッド表示 / リスト表示。ボタン aria-label="グリッド表示"/"リスト表示"。狭い幅では切替ボタン自体が無い)
  //    グリッド: project-grid > project-button(タイトル .project-button-title、日付/ソース数 .project-button-subtitle-part)
  //    リスト  : table 行 tr.mdc-data-table__row(タイトル a.project-table-title、td に「出典: N 件」「日付」)
  //    どちらも ノートブックへのリンク a[href^="/notebook/<uuid>"] が行/カードの中にある → リンクを起点に、
  //    最も近い行/カードからタイトルとメタを読めば、表示形式に依存しない。
  //  「おすすめ」(.featured-projects-container / .single-row-layout)は他人の公開ノートブックなので除外する。
  //  検索  button[aria-label="ノートブックを検索"] を押すと input[aria-label="ノートブックを検索"] が出る(タイトルで絞り込み)。
  //        絞り込み中はリスト表示だと結果が .all-projects-container に出る(.my-projects-container は空) → 見えているリンク全体を読む。
  const HOME = {
    newButton: () => firstVisible([...document.querySelectorAll('button[aria-label="新しいノートブック"]')]),
    searchOpen: () => document.querySelector('button[aria-label="ノートブックを検索"]'),
    searchInput: () => document.querySelector('input[aria-label="ノートブックを検索"]'),
    links: () => [...document.querySelectorAll('a[href^="/notebook/"]')].filter((a) => isVisible(a) && !a.closest(".featured-projects-container,.single-row-layout") && !/\/notebook\/creating/.test(a.getAttribute("href"))),
    card: (a) => a.closest("project-button, tr.mdc-data-table__row") || a.parentElement,
    title: (card) => (card.querySelector(".project-button-title, .project-table-title")?.textContent || "").replace(/\s+/g, " ").trim(),
    emoji: (card) => (card.querySelector(".project-button-box-icon, .project-table-emoji")?.textContent || "").trim(),
    meta: (card) => [...card.querySelectorAll(".project-button-subtitle-part, td")].map((x) => x.textContent.replace(/\s+/g, " ").trim()).filter((t) => /\d{4}\/\d{2}\/\d{2}|ソース|出典/.test(t)),
    uuid: /\/notebook\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/,
  };
  const readHome = () => {
    const seen = new Set();
    return HOME.links().flatMap((a) => {
      const id = HOME.uuid.exec(a.getAttribute("href"))?.[1];
      if (!id || seen.has(id)) return [];
      seen.add(id);
      const card = HOME.card(a);
      const meta = HOME.meta(card);
      const emoji = HOME.emoji(card);
      let title = HOME.title(card);
      if (emoji && title.startsWith(emoji)) title = title.slice(emoji.length).trim(); // リスト表示ではリンク内に絵文字も入る
      return [{ id, url: location.origin + "/notebook/" + id, title, emoji, meta: meta.join(" / ") }];
    });
  };

  /** 最近のノートブックの一覧。query があればタイトル検索(サイトの検索欄を使い、終わったら空に戻す)。 */
  async function listNotebooks(override = {}) {
    const CFG = { query: "", limit: 50, ...override };
    if (!(await waitFor(() => HOME.links().length || HOME.newButton(), 8000)))
      return { ok: false, reason: "【HOME.links】ホーム画面の一覧が見つかりません(ホームを開いていますか?)" };
    if (!CFG.query) return { ok: true, notebooks: readHome().slice(0, CFG.limit) };
    if (!HOME.searchInput()) { HOME.searchOpen()?.click(); await waitFor(() => HOME.searchInput(), 3000); }
    const box = HOME.searchInput();
    if (!box) return { ok: false, reason: "【HOME.searchOpen / searchInput】検索欄が開きません" };
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(box, CFG.query);
    box.dispatchEvent(new Event("input", { bubbles: true }));
    await sleep(1500); // 絞り込み結果が描画されるのを待つ
    const notebooks = readHome().slice(0, CFG.limit);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(box, "");
    box.dispatchEvent(new Event("input", { bubbles: true }));
    return { ok: true, notebooks, query: CFG.query };
  }

  /**
   * 新しいノートブックを作る。遷移 "/" → "/notebook/creating" → "/notebook/<uuid>" を200msごとに監視し、
   * <uuid> に着いたらその URL を返す。title があれば作成後に題名欄(input.title-input)へ入れる(未検証)。
   */
  async function createNotebook(override = {}) {
    const CFG = { title: "", timeoutMs: 45000, ...override };
    const btn = await waitFor(() => HOME.newButton(), 8000);
    if (!btn) return { ok: false, reason: "【HOME.newButton】「新しいノートブック」ボタンが見つかりません" };
    const transitions = [location.pathname];
    const track = setInterval(() => { if (transitions[transitions.length - 1] !== location.pathname) transitions.push(location.pathname); }, 100);
    try {
      btn.click();
      const t0 = Date.now();
      let id = null;
      while (Date.now() - t0 < CFG.timeoutMs && !id) { await sleep(200); id = HOME.uuid.exec(location.pathname)?.[1]; }
      if (!id) return { ok: false, reason: "作成後の URL に遷移しませんでした", transitions };
      let title = "";
      if (CFG.title) {
        const input = await waitFor(() => document.querySelector("input.title-input"), 8000);
        if (input) {
          Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, CFG.title);
          input.dispatchEvent(new Event("input", { bubbles: true }));
          input.dispatchEvent(new Event("change", { bubbles: true }));
          input.blur();
          await sleep(800);
          title = input.value;
        }
      }
      return { ok: true, id, url: location.origin + "/notebook/" + id, title, transitions: [...transitions, location.pathname] };
    } finally { clearInterval(track); }
  }
  window.__nblListNotebooks = listNotebooks;
  window.__nblCreateNotebook = createNotebook;


  // ═══════════════ ノートブックの削除(ホーム画面) ═══════════════
  // 実機で確認した構造(2026-10): カード/行の button[aria-label="プロジェクトの操作メニュー"] → メニュー
  //   「タイトルを編集 / コレクションに追加 / 上部に固定 / 削除」→ 確認ダイアログ
  //   「このノートブックを削除しますか?このノートブックとそのすべてのコンテンツは…完全に削除されます」[キャンセル][削除]。
  //   ※ 確認ダイアログに【ノートブック名は出ない】ので、取り違え防止は「押す前」にやる:
  //      ① id(URLの uuid)で行を特定 ② 期待するタイトルと一致しなければ中止 ③ 開いたメニューは自分が開いたものだけ操作
  //   復元はできない(完全削除)。dryRun:true なら確認ダイアログを開いて「キャンセル」するだけ。
  const HOME_DEL = {
    menuButton: (card) => [...card.querySelectorAll("button")].find((b) => b.getAttribute("aria-label") === "プロジェクトの操作メニュー"),
    menuItems: () => [...document.querySelectorAll(".mat-mdc-menu-panel button")],
    deletePattern: /削除/,
    dialog: () => [...document.querySelectorAll("mat-dialog-container")].find((d) => /このノートブックを削除/.test(d.innerText || "")),
    btn: (dlg, text) => [...dlg.querySelectorAll("button")].find((b) => (b.innerText || "").trim() === text),
  };
  async function deleteNotebook(override = {}) {
    const CFG = { id: "", expectTitle: null, dryRun: false, timeoutMs: 15000, ...override };
    if (!/^[0-9a-f-]{36}$/.test(CFG.id)) return { ok: false, reason: "id が不正です" };
    if (!(await waitFor(() => HOME.links().length, 8000))) return { ok: false, reason: "【HOME.links】ホームの一覧が見つかりません(ホームを開いていますか?)" };
    // 検索で絞り込まれていると一覧が違うので、検索欄は空にしてから探す
    const box = HOME.searchInput();
    if (box && box.value) { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(box, ""); box.dispatchEvent(new Event("input", { bubbles: true })); await sleep(1200); }
    const findCard = () => { const a = HOME.links().find((x) => (HOME.uuid.exec(x.getAttribute("href")) || [])[1] === CFG.id); return a ? HOME.card(a) : null; };
    const card = findCard();
    if (!card) return { ok: false, reason: "該当のノートブックが一覧にありません(すでに削除済み?)" };
    const emoji = HOME.emoji(card);
    let title = HOME.title(card);
    if (emoji && title.startsWith(emoji)) title = title.slice(emoji.length).trim();
    if (CFG.expectTitle != null && title !== CFG.expectTitle) return { ok: false, reason: "タイトルが一致しないため中止しました(実際: " + title + ")" };

    if (document.querySelector(".mat-mdc-menu-panel")) { document.querySelector(".cdk-overlay-backdrop")?.click(); await sleep(500); }
    HOME_DEL.menuButton(card)?.click();
    const item = await waitFor(() => HOME_DEL.menuItems().find((b) => HOME_DEL.deletePattern.test(b.innerText)), 3000);
    if (!item) return { ok: false, reason: "【HOME_DEL.menuButton / menuItems】削除メニューが開きません" };
    item.click();
    const dlg = await waitFor(() => HOME_DEL.dialog(), 4000);
    if (!dlg) return { ok: false, reason: "【HOME_DEL.dialog】削除の確認ダイアログが出ません" };
    if (CFG.dryRun) { HOME_DEL.btn(dlg, "キャンセル")?.click(); await sleep(600); return { ok: true, dryRun: true, id: CFG.id, title }; }
    HOME_DEL.btn(dlg, "削除").click();
    const gone = await waitFor(() => !findCard(), CFG.timeoutMs, 300);
    if (!gone) return { ok: false, reason: "削除が反映されませんでした", id: CFG.id, title };
    return { ok: true, id: CFG.id, title };
  }
  window.__nblDeleteNotebook = deleteNotebook;


  // ═══════════════ チャット履歴の削除(ノートブック画面) ═══════════════
  // 実機で確認した構造(2026-10): 右上 button[aria-label="ノートブックの設定"](︙)→ メニューに
  //   「チャットを設定 / ノートブックをカスタマイズ / ノートブックをコピーする / チャットの履歴を削除」。
  //   「チャットの履歴を削除」を押したあとの【確認ダイアログの文言・ボタンは未確認】(削除は元に戻せないため実機で押していない)。
  //   → 確認ダイアログは「mat-dialog-container のうち本文に『チャット』を含むもの」として探し、
  //     確定ボタンは「キャンセル/閉じる/戻る 以外で、削除・クリア・はい・確認 を含むボタン」とする。
  //   dryRun:true は、ダイアログを開いて【本文とボタン名を返し】、キャンセルして閉じるだけ(何も消さない)。
  //   確定後は、チャットのやり取り(.chat-message-pair)が0件になるのを確認する。
  const CHATDEL = {
    settingsButton: () => firstVisible([...document.querySelectorAll('button[aria-label="ノートブックの設定"]')]),
    menuItems: () => [...document.querySelectorAll(".mat-mdc-menu-panel button")],
    itemPattern: /チャットの履歴を削除/,
    dialog: () => [...document.querySelectorAll("mat-dialog-container")].find((d) => /チャット/.test(d.innerText || "")),
    cancelPattern: /キャンセル|閉じる|戻る|いいえ/,
    confirmPattern: /削除|クリア|はい|確認|OK/,
    pairs: () => document.querySelectorAll(".chat-message-pair").length,
  };
  async function clearChat(override = {}) {
    const CFG = { dryRun: false, timeoutMs: 15000, ...override };
    const btn = await waitFor(() => CHATDEL.settingsButton(), 8000);
    if (!btn) return { ok: false, reason: "【CHATDEL.settingsButton】「ノートブックの設定」ボタンが見つかりません" };
    const before = CHATDEL.pairs();
    if (document.querySelector(".mat-mdc-menu-panel")) { document.querySelector(".cdk-overlay-backdrop")?.click(); await sleep(500); }
    await pressEl(btn);
    const item = await waitFor(() => CHATDEL.menuItems().find((b) => CHATDEL.itemPattern.test(b.innerText || "")), 4000);
    if (!item) return { ok: false, reason: "【CHATDEL.menuItems】「チャットの履歴を削除」メニューが開きません" };
    await pressEl(item);
    // 確認なしで即削除される場合もあるので、ダイアログが出なければ結果で判定する
    const dlg = await waitFor(() => CHATDEL.dialog(), 4000);
    if (!dlg) {
      if (CFG.dryRun) return { ok: false, dryRun: true, reason: "確認ダイアログが出ませんでした(dryRun では削除済みの可能性があります。チャット欄を確認してください)" };
      const gone0 = await waitFor(() => CHATDEL.pairs() === 0, CFG.timeoutMs, 300);
      return gone0 ? { ok: true, before, noConfirm: true } : { ok: false, reason: "確認ダイアログも削除結果も確認できませんでした", before, after: CHATDEL.pairs() };
    }
    const bs = [...dlg.querySelectorAll("button")].filter(isVisible);
    const names = bs.map((b) => (b.innerText || "").trim());
    const cancel = bs.find((b) => CHATDEL.cancelPattern.test((b.innerText || "").trim()));
    const confirm = bs.find((b) => b !== cancel && CHATDEL.confirmPattern.test((b.innerText || "").trim()));
    const text = (dlg.innerText || "").replace(/\s+/g, " ").slice(0, 160);
    if (CFG.dryRun) {
      if (cancel) await pressEl(cancel); else document.querySelector(".cdk-overlay-backdrop")?.click();
      await sleep(600);
      return { ok: !!confirm, dryRun: true, dialogText: text, buttons: names, confirmFound: !!confirm, before };
    }
    if (!confirm) return { ok: false, reason: "【CHATDEL.confirmPattern】確定ボタンが見つかりません: " + names.join(" / "), dialogText: text };
    await pressEl(confirm);
    const gone = await waitFor(() => CHATDEL.pairs() === 0 && !CHATDEL.dialog(), CFG.timeoutMs, 300);
    if (!gone) return { ok: false, reason: "削除が反映されませんでした(チャット " + CHATDEL.pairs() + " 件残り)", before };
    return { ok: true, before };
  }
  window.__nblClearChat = clearChat;


  // ═══════════════ 「notebook 側の更新が落ち着いたか」の判定(次の作業へ進む前の待ち) ═══════════════
  // ソース追加の直後は、取り込み処理中で Studio のボタン等が反応しない(実機の失敗例: 取り込み中に「スライド資料」を押して
  // 設定ダイアログが出なかった)。取り込み中の表示は画面から直接は特定できなかったため、次の複数の兆候で「静かになった」を判定する:
  //   ① 進行中の表示(spinner / progressbar、ソース行の progress_activity・sync アイコン)が無い
  //   ② ダイアログ・メニュー(自分が開いたもの)が残っていない
  //   ③ ソース一覧の構成(件数・名前・エラー数)が quietMs の間、変わっていない
  const IDLE = {
    spinners: () => [...document.querySelectorAll("mat-spinner,mat-progress-spinner,mat-progress-bar,[role=progressbar]")].filter((e) => isVisible(e) && !e.closest("mat-dialog-container")), // ダイアログ内の「28 / 50」のソース上限バーは進行中ではない(実機で確認)
    
    busyRowIcons: () => [...document.querySelectorAll(".single-source-container mat-icon")].filter((i) => /^(progress_activity|sync|hourglass_top|hourglass_empty)$/.test((i.textContent || "").trim())),
    overlays: () => document.querySelectorAll("mat-dialog-container,.mat-mdc-menu-panel").length,
    signature: () => SITE.sourceItems().map(SITE.sourceName).join("\u0001") + "|" + SITE.errorIcons().length,
  };
  async function waitIdle(override = {}) {
    const CFG = { timeoutMs: 60000, quietMs: 2500, ...override };
    const t0 = Date.now();
    let sig = IDLE.signature(), since = Date.now();
    while (Date.now() - t0 < CFG.timeoutMs) {
      await sleep(500);
      const now = IDLE.signature();
      if (now !== sig) { sig = now; since = Date.now(); }
      const busy = IDLE.spinners().length || IDLE.busyRowIcons().length || (CFG.allowOverlays ? 0 : IDLE.overlays());
      if (!busy && Date.now() - since >= CFG.quietMs) return { ok: true, waitedMs: Date.now() - t0 };
    }
    return { ok: false, timedOut: true, waitedMs: Date.now() - t0 };
  }
  window.__nblWaitIdle = waitIdle;

  window.__nblUploadFiles = uploadFiles;
})();
