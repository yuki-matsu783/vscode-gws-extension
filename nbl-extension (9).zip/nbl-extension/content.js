/**
 * content.js — GitHub のページに「Notebookに追加」フローティングボタンを出す。
 *
 * 意図:
 *  - GitHub は SPA(Turbo)でページ遷移するため、URL を定期的に見て対象を判定し直す。
 *  - 対象の判定は parseTarget() だけに集約(GitHub の URL 体系が変わったらここだけ直す)。
 *      /owner/repo[/tree/ref[/dir]]  → リポジトリ全体(ref があればそのブランチ/タグ)
 *      /owner/repo/blob/ref/path     → そのファイル(raw を取得)
 *  - ボタンは Shadow DOM に入れ、GitHub 側の CSS と干渉しないようにする。
 *  - 実際の取得・変換・登録は background.js。ここは「押された」を伝えて進捗を表示するだけ。
 */
(() => {
  if (window.__nblContent) return;
  window.__nblContent = true;

  const RESERVED = new Set(["settings", "orgs", "login", "marketplace", "explore", "topics", "notifications",
    "pulls", "issues", "search", "sponsors", "features", "pricing", "about", "new", "codespaces", "dashboard", "users"]);

  // ★ GitHub の URL 体系依存部分はここだけ
  function parseTarget(loc = location) {
    const p = loc.pathname.split("/").filter(Boolean).map(decodeURIComponent);
    if (p.length < 2 || RESERVED.has(p[0])) return null;
    const [owner, repo, kind, ref, ...rest] = p;
    if (kind === "blob" && ref && rest.length) {
      const path = rest.join("/");
      return { type: "file", owner, repo, ref, path, name: rest[rest.length - 1], pageUrl: loc.href,
        rawUrl: `https://raw.githubusercontent.com/${owner}/${repo}/${encodeURI(ref)}/${path.split("/").map(encodeURIComponent).join("/")}` };
    }
    if (p.length === 2 || kind === "tree") {
      return { type: "repo", owner, repo, ref: kind === "tree" ? ref : null };
    }
    return null;
  }

  const host = document.createElement("div");
  host.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
    <style>
      button{font:600 13px/1 system-ui,sans-serif;color:#fff;background:#1a73e8;border:0;border-radius:999px;
        padding:11px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.35);max-width:320px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      button:hover{background:#1765cc} button:disabled{background:#6b7280;cursor:default}
    </style><button type="button"></button>`;
  const btn = root.querySelector("button");
  let target = null, busy = false;

  const label = () => (target?.type === "file" ? `📓 ${target.name} を Notebook に追加` : "📓 このリポジトリを Notebook に追加");
  function refresh() {
    if (busy) return;
    target = parseTarget();
    if (!target) { host.remove(); return; }
    if (!host.isConnected) document.documentElement.appendChild(host);
    btn.textContent = label();
    btn.disabled = false;
  }
  setInterval(refresh, 1000);
  refresh();

  btn.addEventListener("click", async () => {
    if (busy || !target) return;
    busy = true; btn.disabled = true; btn.textContent = "準備中…";
    try {
      const res = await chrome.runtime.sendMessage({ type: "github-add", target });
      btn.textContent = res?.ok ? "✅ " + res.message : "⚠ " + (res?.error || "失敗しました");
    } catch (e) {
      btn.textContent = "⚠ " + e.message;
    }
    setTimeout(() => { busy = false; refresh(); }, 5000);
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "progress" && busy) btn.textContent = "⏳ " + msg.text;
  });
})();
