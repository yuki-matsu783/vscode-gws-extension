/**
 * ============================================================================
 *  background.js — 拡張の Service Worker(全体の司令塔)
 * ============================================================================
 *
 * 【やること】
 *   1. ファイルを手に入れる
 *        (a) ダウンロード完了 → 通知の「Notebook に追加」ボタン、またはツールバーのポップアップから
 *        (b) GitHub のページに出るフローティングボタン(content.js)から
 *            ・リポジトリ → archive.zip を取得して展開し、テキストを Markdown にまとめる
 *            ・ファイル   → そのファイルの raw を取得(対応形式でなければ Markdown で包む)
 *   2. notebook を【裏で】開く(既定は小さな別ウィンドウ。いまのタブは切り替えない)
 *   3. page/uploader.js を notebook のタブに注入し、ファイルを分割して渡す
 *   4. uploader.js が出す「ボタンの座標」へ、chrome.debugger で本物のクリックを送る
 *   5. 結果を通知に出し、開いた裏のウィンドウを閉じる
 *
 * 【なぜ chrome.debugger でクリックするのか】
 *   notebook の「ファイルをアップロード」ボタンは、スクリプトの click() を無視する(isTrusted=false)。
 *   DevTools と同じ CDP の Input.dispatchMouseEvent なら「本物のクリック」として届く。
 *   代償として、使っている間だけ Chrome に「このブラウザはデバッグされています」の帯が出る。
 *
 * 【安全面の方針】
 *   - 自動でクリックするのは、この拡張が開いた(または指定した)notebook.google.com のタブだけ。
 *   - ダウンロードしたファイルは、通知のボタンを押したときだけ送る(設定で自動にもできるが既定はオフ)。
 *   - ファイルの中身は notebook.google.com 以外には送らない。
 */
importScripts("lib.js");
const { basename, guessMime, extensionAllowed, pathToFileUrl, bytesToBase64, safeName, zipList, zipRead, pathSkipReason, buildRepoMarkdown } = self.NBL;

// ═══════════════ 設定 ═══════════════
const DEFAULTS = {
  notebookUrl: "",            // 例: https://notebook.google.com/notebook/<id>
  windowMode: "tab",          // "tab": 同じウィンドウの裏タブ(既定) / "popup": 小さな別ウィンドウ
  extensions: "pdf,docx,pptx,xlsx,txt,md,csv", // ダウンロード通知を出す拡張子(空欄=すべて)
  promptOnDownload: true,     // ダウンロード完了時に「追加しますか?」通知を出す
  autoAdd: false,             // true: 確認なしで自動追加(既定オフ)
  perRepoNotebook: false,     // GitHub のリポジトリごとに専用ノートブックを作って使い分ける(初回に自動作成して記憶)
  repoMap: {},                // { "owner/repo": "https://notebook.google.com/notebook/<id>" }
  notebooks: [],              // 登録済みノートブック一覧 [{id,url,title}]
  slidesAfterGithub: true,    // GitHub ボタンで登録した後、続けて「スライド資料」を生成してダウンロードする
  slidesFormat: "pptx",       // "pptx" | "pdf"
};
const NOTEBOOK_URL_RE = /^https:\/\/notebook\.google\.com\/notebook\/[^/?#]+/;
async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// 動作ログ(直近40行)。「何が起きて/起きなかったか」を後から見られるようにする。ポップアップの「動作ログ」に表示。
let traceChain = Promise.resolve();
function trace(line) {
  traceChain = traceChain.then(async () => {
    const { trace: t = [] } = await chrome.storage.local.get("trace");
    t.push(new Date().toLocaleTimeString() + " " + line);
    await chrome.storage.local.set({ trace: t.slice(-40) });
  }).catch(() => {});
}

function notify(id, title, message) {
  // 失敗の通知は全文を保存し、ポップアップの「前回のエラー詳細」で見られるようにする(通知は300字で切れるため)
  if (id.startsWith("nbl-err") || id === "nbl-warn" || id === "nbl-del") chrome.storage.local.set({ lastError: { at: Date.now(), title, message: String(message) } }).catch(() => {});
  chrome.notifications.create(id, { type: "basic", iconUrl: "icons/icon128.png", title, message: String(message).slice(0, 300) });
}

// 同時に1件ずつ処理する(notebook のウィンドウやデバッガを取り合わないため)
let queue = Promise.resolve();
function enqueue(fn) {
  const p = queue.then(fn);
  queue = p.catch(() => {});
  return p;
}

// ═══════════════ 永続キュー(最大10件・1件ずつ処理) ═══════════════
// 拡張からの「notebook を操作する依頼」(ダウンロード追加 / GitHub / ポップアップ・右クリックの各タスク)は、ここに積んで1件ずつ処理する。
//  - 保存先 chrome.storage.local["jobs"]。SW が止まっても残る。実行中だったものは再起動時に「中断」として破棄(二重実行や
//    スライド生成の重複消費を避けるため)。
//  - 各ジョブの終了時に、notebook 側の更新(取り込み等)が落ち着くのを待ち、さらに1秒空けてから次へ進む。
//  - 一覧取得・ノートブックの作成/削除など「画面操作だけの短い処理」は従来どおり enqueue() で直列化(キューの件数には数えない)。
const QUEUE_MAX = 10;
const jobWaiters = new Map(); // jobId → sendResponse(結果を待っているポップアップ等)
const jobsGet = async () => (await chrome.storage.local.get("jobs")).jobs || [];
const jobsSet = (jobs) => chrome.storage.local.set({ jobs });
// 読み→変更→書きの競合を防ぐ(短時間に複数の依頼が来ると、互いの追加を上書きして消してしまうため。模擬試験で確認した不具合)。
// 保存内容を変える処理は必ずこの withJobs を通す。fn は現在の配列を受け取り、新しい配列(または undefined=変更なし)を返す。
let jobsLock = Promise.resolve();
function withJobs(fn) {
  const p = jobsLock.then(async () => {
    const jobs = await jobsGet();
    const out = await fn(jobs);
    if (out) await jobsSet(out);
    return out || jobs;
  });
  jobsLock = p.catch(() => {});
  return p;
}

async function submitJob(kind, payload, label, waiter) {
  const job = { id: Math.random().toString(36).slice(2) + Date.now().toString(36), kind, payload, label, at: Date.now(), running: false };
  let position = 0, full = false;
  await withJobs((jobs) => {
    if (jobs.length >= QUEUE_MAX) { full = true; return; }
    jobs.push(job);
    position = jobs.length;
    return jobs;
  });
  if (full) {
    trace("キュー満杯のため拒否: " + label);
    throw new Error("キューがいっぱいです(最大" + QUEUE_MAX + "件)。処理が進んでから追加してください");
  }
  if (waiter) jobWaiters.set(job.id, waiter);
  trace("キュー追加(" + position + "件目): " + label);
  kickQueue();
  return { job, position };
}

async function runJob(job) {
  const p = job.payload;
  if (job.kind === "download") return sendDownload(p.id);
  if (job.kind === "task") return runEntryTask(p.task);
  if (job.kind === "github") {
    const progress = (text) => p.tabId != null && chrome.tabs.sendMessage(p.tabId, { type: "progress", text }).catch(() => {});
    return addFromGithub(p.target, progress);
  }
  throw new Error("未知のジョブ: " + job.kind);
}

let draining = false;
async function kickQueue() {
  if (draining) return;
  draining = true;
  try {
    for (;;) {
      let job = null, left = 0;
      await withJobs((jobs) => { job = jobs[0]; left = jobs.length - 1; if (job) { job.running = true; return jobs; } });
      if (!job) break;
      trace("キュー実行: " + job.label + "(残り" + left + "件)");
      let result = null, error = null;
      try { result = await enqueue(() => runJob(job)); } catch (e) { error = e; }
      await withJobs((jobs) => jobs.filter((j) => j.id !== job.id));
      if (error) { trace("キュー失敗: " + job.label + " " + error.message); notify("nbl-err-" + job.kind, "追加に失敗", error.message); }
      const w = jobWaiters.get(job.id);
      if (w) { jobWaiters.delete(job.id); w(error ? { ok: false, error: error.message } : { ok: true, message: result }); }
      await sleep(1000); // 終わって1秒空けてから次へ(各ジョブの最後に notebook の更新待ちも済んでいる)
    }
  } finally { draining = false; }
}
// SW が再起動したとき: 実行中だったものは中断扱いで破棄し、残りがあれば続ける
(async () => {
  let dropped = 0, left = 0;
  await withJobs((jobs) => { const rest = jobs.filter((j) => !j.running); dropped = jobs.length - rest.length; left = rest.length; return rest; });
  if (dropped) trace("再起動で中断されたジョブを破棄: " + dropped + "件");
  if (left) kickQueue();
})();

/** 1つのジョブの最後に呼ぶ: notebook 側の更新(取り込み等)が落ち着くのを待つ。タブを閉じる直前に。 */
async function waitNotebookIdle(tabId) {
  try {
    await evalInTab(tabId, () => { window.__nblIdle = null; window.__nblWaitIdle({ timeoutMs: 60000, quietMs: 2500, allowOverlays: false }).then((r) => (window.__nblIdle = r)); return true; });
    for (let i = 0; i < 130; i++) { await sleep(500); const r = await evalInTab(tabId, () => window.__nblIdle || null); if (r) { trace("notebook 更新待ち: " + (r.ok ? "落ち着きました" : "タイムアウト") + " " + r.waitedMs + "ms"); break; } }
  } catch { /* タブが無い等。待てなくても先へ進む */ }
}

// ═══════════════ 入口(a): ダウンロード ═══════════════
chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state || delta.state.current !== "complete") return;
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item) return;
  const s = await getSettings();
  trace("download完了: " + basename(item.filename) + " (autoAdd:" + s.autoAdd + " prompt:" + s.promptOnDownload + ")");
  if (!s.promptOnDownload && !s.autoAdd) { trace("  → 無視(通知も自動追加もオフ)"); return; }
  if (!extensionAllowed(item.filename, s.extensions)) { trace("  → 無視(拡張子が対象外: " + s.extensions + ")"); return; }
  if (!NOTEBOOK_URL_RE.test(s.notebookUrl)) {
    trace("  → 中止(ノートブックのURL未設定)");
    notify("nbl-setup", "Notebook 連携", "ノートブックのURLが未設定です。拡張のオプションで設定してください。");
    return;
  }
  if (s.autoAdd) {
    trace("  → 自動追加を開始");
    submitJob("download", { id: item.id }, basename(item.filename)).catch((e) => notify("nbl-err-queue", "キューに追加できません", e.message));
    return;
  }
  chrome.notifications.create("nbl-dl-" + item.id, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "ダウンロード完了",
    message: basename(item.filename) + " を Notebook に追加しますか?",
    buttons: [{ title: "Notebook に追加" }],
    requireInteraction: true,
  });
});

chrome.notifications.onButtonClicked.addListener((id, index) => {
  if (!id.startsWith("nbl-dl-") || index !== 0) return;
  const downloadId = Number(id.slice("nbl-dl-".length));
  chrome.notifications.clear(id);
  submitJob("download", { id: downloadId }, "ダウンロード#" + downloadId).catch((e) => notify("nbl-err-queue", "キューに追加できません", e.message));
});

/** ダウンロード済みファイルのバイト列を読む。失敗理由は両方の試行ぶんを文面に含める(原因調査のため)。 */
async function readDownload(item) {
  const name = basename(item.filename);
  const reasons = [];
  // 1) ローカルの実ファイルを読む。次の2つが両方必要:
  //    ① manifest の host_permissions に file:///*(これが無いと、スイッチがオンでも fetch は失敗する)
  //    ② chrome://extensions の詳細で「ファイルのURLへのアクセスを許可する」をオン
  let fileAccess = null;
  try { fileAccess = await chrome.extension.isAllowedFileSchemeAccess(); } catch { /* 取得できない環境 */ }
  const fileUrl = pathToFileUrl(item.filename);
  try {
    const res = await fetch(fileUrl);
    if (res.ok) return { name, type: guessMime(name, item.mime), bytes: new Uint8Array(await res.arrayBuffer()) };
    reasons.push("ローカル読み取り: HTTP " + res.status);
  } catch (e) { reasons.push("ローカル読み取り(" + fileUrl + "): " + (e && e.message)); }
  // 2) 取得元URLをもう一度取りにいく(ログイン Cookie 付き)。ワンタイムURL・blob:・他サイト(CORS)では失敗することがある。
  const url = item.finalUrl || item.url;
  if (/^https?:/.test(url)) {
    try {
      const res = await fetch(url, { credentials: "include" });
      if (res.ok) return { name, type: guessMime(name, item.mime), bytes: new Uint8Array(await res.arrayBuffer()) };
      reasons.push("再取得: HTTP " + res.status);
    } catch (e) { reasons.push("再取得: " + (e && e.message)); }
  } else reasons.push("再取得: 取得元URLが http(s) ではありません(" + String(url).slice(0, 20) + ")");
  const hint = fileAccess === false
    ? "「ファイルのURLへのアクセスを許可する」がオフです(chrome://extensions → この拡張の詳細)。"
    : fileAccess === true
      ? "ファイルアクセスの許可はオンです。拡張を再読み込みし(新しい版のmanifestに file:///* を追加済み)、それでも失敗する場合は下の詳細を確認してください。"
      : "ファイルアクセスの許可状態を確認できませんでした。";
  throw new Error("ファイルを読み取れませんでした。" + hint + "\n" + reasons.join("\n"));
}

async function sendDownload(downloadId) {
  const [item] = await chrome.downloads.search({ id: downloadId });
  if (!item || item.exists === false) throw new Error("ダウンロードしたファイルが見つかりません(削除または移動された可能性)");
  const file = await readDownload(item);
  await uploadToNotebook([file]);
}

// ═══════════════ 入口(b): GitHub ═══════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "send-download") {
    submitJob("download", { id: msg.id }, "ダウンロード#" + msg.id, sendResponse).catch((e) => sendResponse({ ok: false, error: e.message }));
    return true; // 処理が終わったら(キューの順番が来て完了したら)応答する
  }
  if (msg?.type === "notebook-task") {
    const t = msg.task;
    const label = { chat: "質問", search: "検索", urls: "URL追加", text: "テキスト追加" }[t.type] + ": " + String(t.prompt || t.query || (t.urls || [])[0] || t.text || "").slice(0, 24);
    submitJob("task", { task: t }, label, sendResponse).catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === "queue-list") { jobsGet().then((jobs) => sendResponse({ ok: true, jobs: jobs.map((j) => ({ id: j.id, label: j.label, running: j.running })) })); return true; }
  if (msg?.type === "queue-remove") {
    withJobs((jobs) => jobs.filter((j) => j.id !== msg.id || j.running)).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "create-notebook") {
    enqueue(() => createNotebook(msg)).then((r) => sendResponse({ ok: true, notebook: r }), (e) => { notify("nbl-err-nb", "作成に失敗", e.message); sendResponse({ ok: false, error: e.message }); });
    return true;
  }
  if (msg?.type === "delete-notebook") {
    enqueue(() => deleteNotebook(msg)).then((r) => sendResponse({ ok: true, result: r }), (e) => { notify("nbl-err-del", "削除に失敗", e.message); sendResponse({ ok: false, error: e.message }); });
    return true;
  }
  if (msg?.type === "refresh-notebooks") {
    enqueue(() => refreshNotebooks()).then((r) => sendResponse({ ok: true, notebooks: r }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === "list-notebooks") {
    enqueue(() => listNotebooks(msg.query || "")).then((r) => sendResponse({ ok: true, notebooks: r }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === "github-add") {
    trace("GitHub追加 受信: " + (msg.target?.type) + " " + (msg.target?.repo || "") + (msg.target?.name ? "/" + msg.target.name : ""));
    const label = "GitHub: " + (msg.target.repo || "") + (msg.target.name ? "/" + msg.target.name : "");
    submitJob("github", { target: msg.target, tabId: sender.tab?.id ?? null }, label).then(
      ({ position }) => sendResponse({ ok: true, message: position > 1 ? "キューに追加しました(" + position + "件目)" : "キューに追加しました" }),
      (e) => sendResponse({ ok: false, error: e.message })
    );
    return true;
  }
});

async function fetchBytes(url, maxBytes) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error("取得に失敗しました(HTTP " + res.status + "): " + url);
  const len = Number(res.headers.get("content-length") || 0);
  if (len > maxBytes) throw new Error("サイズが大きすぎます(" + Math.round(len / 1048576) + "MB)。上限は " + Math.round(maxBytes / 1048576) + "MB です。");
  return new Uint8Array(await res.arrayBuffer());
}

async function addFromGithub(target, progress) {
  if (target.type === "file") {
    progress("ファイルを取得中…");
    const bytes = await fetchBytes(target.rawUrl, 50 * 1048576);
    const name = target.name;
    const passthrough = /\.(md|txt|pdf|docx|pptx|xlsx|csv)$/i.test(name);
    let file;
    if (passthrough) {
      file = { name, type: guessMime(name), bytes };
    } else {
      // ノートブックが受け付けない拡張子(.py など)は、コードブロックにした Markdown に包んで登録する
      const text = new TextDecoder("utf-8").decode(bytes);
      const fence = self.NBL.fenceFor(text);
      const md = "# " + name + "\n\nソース: " + target.pageUrl + "\n\n" + fence + (/\.([^.]+)$/.exec(name)?.[1] || "") + "\n" + text.trimEnd() + "\n" + fence + "\n";
      file = { name: name + ".md", type: "text/markdown", bytes: new TextEncoder().encode(md) };
    }
    progress("Notebook に追加中…");
    await uploadToNotebook([file], progress, { slides: (await getSettings()).slidesAfterGithub, notebookUrl: await notebookForRepo(target.owner, target.repo) });
    return name + " を追加しました";
  }

  // リポジトリ全体: archive.zip → 展開 → Markdown
  const ref = target.ref || "HEAD";
  progress("リポジトリを取得中…");
  const zipUrl = "https://github.com/" + target.owner + "/" + target.repo + "/archive/" + encodeURI(ref) + ".zip";
  const zip = await fetchBytes(zipUrl, 150 * 1048576);
  progress("展開中…");
  const entries = zipList(zip).filter((e) => !e.name.endsWith("/"));
  const root = (entries[0]?.name.split("/")[0] || "") + "/"; // GitHub の ZIP は先頭に "<repo>-<ref>/" が付く
  const MAX_FILE = 200 * 1024;
  const files = [];
  const preSkipped = [];
  for (const e of entries) {
    const path = e.name.startsWith(root) ? e.name.slice(root.length) : e.name;
    const why = pathSkipReason(path) || (e.usize > MAX_FILE ? "大きすぎる(" + Math.round(e.usize / 1024) + "KB)" : null);
    if (why) { preSkipped.push({ path, reason: why }); continue; } // 展開せずに除外(node_modules などを読まない)
    files.push({ path, bytes: await zipRead(zip, e) });
  }
  const md = buildRepoMarkdown({
    owner: target.owner, repo: target.repo, ref, preSkipped,
    sourceUrl: "https://github.com/" + target.owner + "/" + target.repo + (target.ref ? "/tree/" + target.ref : ""),
    files,
  }, { maxFileBytes: MAX_FILE });
  if (!md.parts.length || !md.included) throw new Error("取り込めるテキストファイルがありませんでした");
  const out = md.parts.map((p) => ({ name: p.name, type: "text/markdown", bytes: new TextEncoder().encode(p.text) }));
  progress("Notebook に追加中(" + out.length + "ファイル)…");
  await uploadToNotebook(out, progress, { slides: (await getSettings()).slidesAfterGithub, notebookUrl: await notebookForRepo(target.owner, target.repo) });
  return target.repo + " を追加しました(" + md.included + "ファイル" + (md.truncated ? "・一部省略" : "") + ")";
}

// ═══════════════ 検索 / URL / コピーしたテキスト(ファイル不要の入口) ═══════════════
/** notebook を裏で開いて準備まで済ませる。close() で後片付け(デバッガ解除・開いたタブ/ウィンドウを閉じる)。 */
async function openNotebookTab(s, { addSource = true, homeUrl = null } = {}) {
  if (!homeUrl && !NOTEBOOK_URL_RE.test(s.notebookUrl)) throw new Error("ノートブックのURLが未設定です。拡張のオプションで設定してください。");
  const url = homeUrl || s.notebookUrl.split(/[?#]/)[0] + (addSource ? "?addSource=true" : ""); // チャットは入力欄を覆うダイアログを開かない
  const h = { tabId: null, createdWindowId: null, createdTabId: null, attached: false };
  h.close = async () => {
    if (h.attached) await chrome.debugger.detach({ tabId: h.tabId }).catch(() => {});
    if (h.createdWindowId != null) await chrome.windows.remove(h.createdWindowId).catch(() => {});
    if (h.createdTabId != null) await chrome.tabs.remove(h.createdTabId).catch(() => {});
  };
  try {
    if (s.windowMode === "tab") {
      const prev = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      const t = await chrome.tabs.create({ url, active: false, windowId: prev?.windowId });
      h.tabId = h.createdTabId = t.id;
    } else {
      const w = await chrome.windows.create({ url, type: "popup", width: 560, height: 860, focused: false });
      h.createdWindowId = w.id;
      h.tabId = w.tabs[0].id;
    }
    await waitTabComplete(h.tabId);
    if (h.createdTabId != null) {
      await chrome.debugger.attach({ tabId: h.tabId }, "1.3"); h.attached = true;
      await chrome.debugger.sendCommand({ tabId: h.tabId }, "Emulation.setFocusEmulationEnabled", { enabled: true }).catch(() => {});
    }
    if ((await evalInTab(h.tabId, () => location.host)) !== "notebook.google.com")
      throw new Error("Google にログインしていません。ログインしてからやり直してください");
    for (let i = 0; ; i++) {
      if (await evalInTab(h.tabId, () => !!document.querySelector('button[aria-label="ソースを追加"], textarea.query-box-input, button[aria-label="新しいノートブック"]'))) break;
      if (i >= 59) throw new Error("notebook の画面が準備できませんでした(URLを確認してください)");
      await sleep(500);
    }
    await chrome.scripting.executeScript({ target: { tabId: h.tabId }, files: ["page/uploader.js"], world: "MAIN" });
    return h;
  } catch (e) { await h.close(); throw e; }
}

/** task: {type:"search",query,mode,scope} | {type:"urls",urls} | {type:"text",text} */
async function runEntryTask(task) {
  const s = { ...(await getSettings()), ...(task.notebookUrl ? { notebookUrl: task.notebookUrl } : {}) };
  trace("タスク開始: " + task.type);
  const h = await openNotebookTab(s, { addSource: false }); // ダイアログは page 側が開く(開きっぱなしだと本物のクリックが幕に当たるため)
  let stopPump = () => {};
  try {
    await evalInTab(h.tabId, () => { window.__nblTrusted = true; return true; }); // 以降の入力/クリックは本物のイベントで実行させる
    stopPump = startPump(h);
    await evalInTab(h.tabId, (task) => {
      window.__nblEntryResult = null; window.__nblEntryProgress = "";
      window.__nblAddEntry(task).then(
        (r) => (window.__nblEntryResult = r),
        (e) => (window.__nblEntryResult = { ok: false, reason: String((e && e.message) || e) })
      );
      return true;
    }, [task]);
    const t0 = Date.now();
    let res = null;
    while (Date.now() - t0 < 25 * 60000) { // 検索(特に Deep)は数分かかる。10秒ごとに確認
      await sleep(task.type === "search" ? 10000 : task.type === "chat" ? 2000 : 1000);
      const st = await evalInTab(h.tabId, () => window.__nblEntryResult || null);
      if (st) { res = st; break; }
    }
    if (!res) throw new Error("時間内に完了しませんでした");
    if (!res.ok) { trace("タスク失敗: " + task.type + " " + (res.reason || "")); throw new Error(res.reason || "失敗しました"); }
    trace("タスク成功: " + task.type);
    if (task.type !== "chat") await waitNotebookIdle(h.tabId);
    if (task.type === "chat") { // 回答は Markdown と素のテキストの両方を保存(ポップアップで表示・コピー)。ジョブの結果は Markdown
      const md = res.markdown || res.answer;
      await chrome.storage.local.set({ lastChat: { prompt: task.prompt, answer: res.answer, markdown: md, at: Date.now() } });
      notify("nbl-chat", "Notebook の回答", res.answer);
      return md;
    }
    const label = { search: "検索結果", urls: "URL", text: "テキスト" }[task.type];
    const msg = label + "を追加しました(" + (res.added ?? 0) + "件)" + (res.summary ? "\n" + res.summary : "");
    if (res.errorIconCount > 0) notify("nbl-warn", "追加しましたが警告があります", msg + "\nノートブック側でエラー表示が出ている可能性があります。");
    else notify("nbl-ok", "Notebook に追加しました", msg);
    return msg;
  } finally { stopPump(); await h.close(); }
}

// 右クリックメニュー(他の画面から直接送る入口)
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    const add = (id, title, contexts) => chrome.contextMenus.create({ id, title, contexts });
    add("nbl-text", "選択テキストを Notebook に追加", ["selection"]);
    add("nbl-page", "このページのURLを Notebook に追加", ["page"]);
    add("nbl-link", "リンク先を Notebook に追加", ["link"]);
    add("nbl-fast", "Notebook で検索(Fast Research)", ["selection"]);
    add("nbl-deep", "Notebook で検索(Deep Research)", ["selection"]);
    add("nbl-ask", "選択テキストを Notebook のチャットで質問", ["selection"]);
  });
});
chrome.contextMenus.onClicked.addListener((info) => {
  const tasks = {
    "nbl-text": { type: "text", text: info.selectionText },
    "nbl-page": { type: "urls", urls: [info.pageUrl] },
    "nbl-link": { type: "urls", urls: [info.linkUrl] },
    "nbl-fast": { type: "search", query: info.selectionText, mode: "fast", scope: "web" },
    "nbl-deep": { type: "search", query: info.selectionText, mode: "deep", scope: "web" },
    "nbl-ask": { type: "chat", prompt: info.selectionText },
  };
  const task = tasks[info.menuItemId];
  if (task) submitJob("task", { task }, "右クリック: " + task.type).catch((e) => notify("nbl-err-queue", "キューに追加できません", e.message));
});

// ═══════════════ ノートブックの作成 / 一覧 / 切り分け ═══════════════
const UUID_URL_RE = /^https:\/\/notebook\.google\.com\/notebook\/([0-9a-f-]{36})/;

async function saveNotebook(nb, makeDefault) {
  const s = await getSettings();
  const list = (s.notebooks || []).filter((x) => x.id !== nb.id);
  list.unshift({ id: nb.id, url: nb.url, title: nb.title || "" });
  const patch = { notebooks: list.slice(0, 100) };
  if (makeDefault) patch.notebookUrl = nb.url; // 既定の送信先にする
  await chrome.storage.sync.set(patch);
  await chrome.storage.local.remove("notebookCache"); // 一覧が変わったので、次に開いたとき取り直す
}

/** ホームを裏で開き、「新しいノートブック」を押して、遷移後の URL を取得して登録する。 */
async function createNotebook({ title = "", makeDefault = true } = {}) {
  const s = await getSettings();
  const h = await openNotebookTab(s, { homeUrl: "https://notebook.google.com/" });
  try {
    await evalInTab(h.tabId, (title) => {
      window.__nblCreate = null;
      window.__nblCreateNotebook({ title }).then((r) => (window.__nblCreate = r), (e) => (window.__nblCreate = { ok: false, reason: String((e && e.message) || e) }));
      return true;
    }, [title]);
    let res = null;
    for (let i = 0; i < 100 && !res; i++) { // 最大約50秒。ページ側が全面遷移で消えても、タブの URL で検知できるようにする
      await sleep(500);
      res = await evalInTab(h.tabId, () => window.__nblCreate || null).catch(() => null);
      if (!res) {
        const m = UUID_URL_RE.exec((await chrome.tabs.get(h.tabId)).url || "");
        if (m && i > 4) { await sleep(1500); res = { ok: true, id: m[1], url: "https://notebook.google.com/notebook/" + m[1], title: "" }; }
      }
    }
    if (!res?.ok) throw new Error(res?.reason || "新しいノートブックを作成できませんでした");
    await saveNotebook(res, makeDefault);
    notify("nbl-created", "ノートブックを作成しました", (res.title || "無題のノートブック") + "\n" + res.url + (makeDefault ? "\n(送信先に設定しました)" : ""));
    return res;
  } finally { await h.close(); }
}

/** ホームを裏で開いて一覧(または検索結果)を返す。表示形式(グリッド/リスト)・幅は page 側が吸収する。 */
async function listNotebooks(query = "") {
  const s = await getSettings();
  const h = await openNotebookTab(s, { homeUrl: "https://notebook.google.com/" });
  try {
    await evalInTab(h.tabId, (query) => {
      window.__nblList = null;
      window.__nblListNotebooks({ query }).then((r) => (window.__nblList = r), (e) => (window.__nblList = { ok: false, reason: String((e && e.message) || e) }));
      return true;
    }, [query]);
    for (let i = 0; i < 60; i++) {
      await sleep(500);
      const r = await evalInTab(h.tabId, () => window.__nblList || null);
      if (r) { if (!r.ok) throw new Error(r.reason); return r.notebooks; }
    }
    throw new Error("一覧を取得できませんでした");
  } finally { await h.close(); }
}

/** 一覧を取得してキャッシュ(storage.local)に保存。ポップアップ/オプションのプルダウンの候補になる。 */
let refreshing = null;
function refreshNotebooks() {
  if (!refreshing) refreshing = listNotebooks("").then(async (items) => { await chrome.storage.local.set({ notebookCache: { at: Date.now(), items } }); return items; }).finally(() => (refreshing = null));
  return refreshing;
}

/** ノートブックを完全に削除する(復元不可)。id と、表示中のタイトルの一致を確認してから実行。 */
async function deleteNotebook({ id, title = null, dryRun = false }) {
  const s = await getSettings();
  const h = await openNotebookTab(s, { homeUrl: "https://notebook.google.com/" });
  try {
    await evalInTab(h.tabId, (id, title, dryRun) => {
      window.__nblDel = null;
      window.__nblDeleteNotebook({ id, expectTitle: title, dryRun }).then((r) => (window.__nblDel = r), (e) => (window.__nblDel = { ok: false, reason: String((e && e.message) || e) }));
      return true;
    }, [id, title, dryRun]);
    let res = null;
    for (let i = 0; i < 80 && !res; i++) { await sleep(500); res = await evalInTab(h.tabId, () => window.__nblDel || null); }
    if (!res?.ok) throw new Error(res?.reason || "削除できませんでした");
    if (!dryRun) { // 登録簿・送信先・リポジトリ対応から外す(消えたノートブックへ送り続けないため)
      const st = await getSettings();
      const patch = { notebooks: (st.notebooks || []).filter((n) => n.id !== id) };
      if ((st.notebookUrl || "").includes(id)) patch.notebookUrl = "";
      patch.repoMap = Object.fromEntries(Object.entries(st.repoMap || {}).filter(([, u]) => !u.includes(id)));
      await chrome.storage.sync.set(patch);
      await chrome.storage.local.remove("notebookCache");
      notify("nbl-deleted", "ノートブックを削除しました", (res.title || id) + (patch.notebookUrl === "" && (st.notebookUrl || "").includes(id) ? "\n(送信先が未設定になりました。選び直してください)" : ""));
    }
    return res;
  } finally { await h.close(); }
}

/** GitHub のリポジトリごとに専用ノートブックを使い分ける。未作成なら作って記憶する。 */
async function notebookForRepo(owner, repo) {
  const s = await getSettings();
  if (!s.perRepoNotebook) return null;
  const key = owner + "/" + repo;
  if (s.repoMap?.[key]) return s.repoMap[key];
  const nb = await createNotebook({ title: key, makeDefault: false });
  await chrome.storage.sync.set({ repoMap: { ...(s.repoMap || {}), [key]: nb.url } });
  return nb.url;
}

// ═══════════════ スライド資料の生成 → ダウンロード ═══════════════
/** 登録に使った同じタブで続けて実行。完成まで5〜10分かかるので、10秒ごとに確認する(タブは開いたままにする)。 */
async function generateSlidesInTab(tabId, format, progress) {
  await evalInTab(tabId, () => { window.__nblTrusted = true; return true; });
  trace("スライド生成を開始");
  notify("nbl-slides-start", "スライド資料を生成中", "完成まで数分〜10分ほどかかります。完成するとダウンロードします。");
  await evalInTab(tabId, (format) => {
    window.__nblSlidesResult = null;
    window.__nblGenerateSlides({ format }).then(
      (r) => (window.__nblSlidesResult = r),
      (e) => (window.__nblSlidesResult = { ok: false, reason: String((e && e.message) || e) })
    );
    return true;
  }, [format]);
  const t0 = Date.now();
  while (Date.now() - t0 < 22 * 60000) {
    await sleep(10000);
    const st = await evalInTab(tabId, () => ({ r: window.__nblSlidesResult || null, p: window.__nblSlidesProgress || "" }));
    if (st.p) progress("スライド生成中: " + st.p);
    if (st.r) {
      if (!st.r.ok) throw new Error("スライド生成: " + st.r.reason);
      trace("スライド生成/ダウンロード操作 完了: " + st.r.title);
      notify("nbl-slides-ok", "スライド資料をダウンロードしました", st.r.title + "(" + st.r.format + ")");
      return;
    }
  }
  throw new Error("スライド生成が時間内に終わりませんでした");
}

// ═══════════════ notebook への登録(本体) ═══════════════
// ── 本物の入力/クリックの実行役。ページ側(page/uploader.js)が window.__nblNeedClick / __nblNeedType に出す依頼を
//    CDP の Input.dispatchMouseEvent / Input.insertText で実行する。依頼は seq で1回だけ処理する。
async function ensureAttached(h) {
  if (h.attached) return;
  try { await chrome.debugger.attach({ tabId: h.tabId }, "1.3"); }
  catch (e) { if (!/already attached/i.test(String(e && e.message))) throw e; }
  h.attached = true;
  await chrome.debugger.sendCommand({ tabId: h.tabId }, "Emulation.setFocusEmulationEnabled", { enabled: true }).catch(() => {});
}
function startPump(h) {
  let stop = false, lastSeq = 0;
  (async () => {
    while (!stop) {
      try {
        const st = await evalInTab(h.tabId, () => ({ c: window.__nblNeedClick || null, t: window.__nblNeedType || null }));
        if (st.t && st.t.seq > lastSeq) {
          lastSeq = st.t.seq;
          await ensureAttached(h);
          await chrome.debugger.sendCommand({ tabId: h.tabId }, "Input.insertText", { text: st.t.text });
        } else if (st.c && st.c.seq && st.c.seq > lastSeq) {
          lastSeq = st.c.seq;
          await ensureAttached(h);
          await trustedClick(h.tabId, st.c.x, st.c.y);
        }
      } catch { /* タブが閉じた等。次の周回で止まる */ }
      await sleep(120);
    }
  })();
  return () => { stop = true; };
}

const evalInTab = async (tabId, func, args = []) => {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func, args });
  return r?.result;
};

function waitTabComplete(tabId, timeout = 40000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { done(); reject(new Error("notebook の読み込みがタイムアウトしました")); }, timeout);
    const onUpdated = (id, info) => { if (id === tabId && info.status === "complete") { done(); resolve(); } };
    const done = () => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(onUpdated); };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((t) => { if (t.status === "complete") { done(); resolve(); } });
  });
}

/** Service Worker からページへ、ファイルを3MBずつ base64 で渡して File に組み立てる。 */
async function transferFiles(tabId, files) {
  const CHUNK = 3 * 1024 * 1024;
  await evalInTab(tabId, () => { window.__nblFiles = []; return true; });
  for (let fi = 0; fi < files.length; fi++) {
    const f = files[fi];
    const total = Math.max(1, Math.ceil(f.bytes.length / CHUNK));
    for (let i = 0; i < total; i++) {
      const b64 = bytesToBase64(f.bytes.subarray(i * CHUNK, (i + 1) * CHUNK));
      await evalInTab(
        tabId,
        (b64, i, total, name, type) => {
          // ※ この関数はページ側で実行される(拡張の変数は見えない)
          if (i === 0) window.__nblParts = [];
          const bin = atob(b64);
          const u8 = new Uint8Array(bin.length);
          for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k);
          window.__nblParts.push(u8);
          if (i === total - 1) { window.__nblFiles.push(new File(window.__nblParts, name, { type })); window.__nblParts = null; }
          return true;
        },
        [b64, i, total, f.name, f.type]
      );
    }
  }
}

/** CDP で「本物のクリック」を送る。 */
async function trustedClick(tabId, x, y) {
  const send = (method, params) => chrome.debugger.sendCommand({ tabId }, method, params);
  await send("Emulation.setFocusEmulationEnabled", { enabled: true }).catch(() => {}); // 裏のウィンドウでも「フォーカスあり」として扱わせる
  await send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
  await send("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1 });
  await send("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1 });
}

async function uploadToNotebook(files, progress = () => {}, opts = {}) {
  const s = { ...(await getSettings()), ...(opts.notebookUrl ? { notebookUrl: opts.notebookUrl } : {}) }; // opts.notebookUrl: この操作だけ別のノートブックへ
  if (!NOTEBOOK_URL_RE.test(s.notebookUrl)) throw new Error("ノートブックのURLが未設定です。拡張のオプションで設定してください。");
  // 同名が重なると追加確認(個数の増減)が曖昧になるので、バッチ内の重複名には番号を付ける
  const seen = new Map();
  files = files.map((f) => {
    const n = seen.get(f.name) || 0;
    seen.set(f.name, n + 1);
    return n ? { ...f, name: f.name.replace(/(\.[^.]+)?$/, "-" + (n + 1) + "$1") } : f;
  });

  const base = s.notebookUrl.split(/[?#]/)[0];
  const url = base + "?addSource=true"; // このパラメータでダイアログが最初から開く(確認済み)
  let tabId, createdWindowId = null, createdTabId = null, attached = false, prevActive = null, foregrounded = false;

  try {
    if (s.windowMode === "tab") {
      // いま使っているウィンドウに、アクティブにならない裏タブとして開く(ユーザーのタブは切り替わらない)。
      // 既存の notebook タブは状態(開いているタブ等)が読めないので再利用せず、必ず専用タブを作る。
      const prev = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      prevActive = prev?.id ?? null;
      const t = await chrome.tabs.create({ url, active: false, windowId: prev?.windowId });
      tabId = createdTabId = t.id;
    } else {
      // 小さな別ウィンドウ。描画が止まらず座標が安定するので既定にしている。フォーカスは奪わない。
      const w = await chrome.windows.create({ url, type: "popup", width: 560, height: 860, focused: false });
      createdWindowId = w.id;
      tabId = w.tabs[0].id;
    }

    await waitTabComplete(tabId);
    if (createdTabId != null) {
      // 裏タブは「非表示」扱いで描画・タイマーが絞られる。早めにデバッガを付け、フォーカスありとして扱わせる。
      await chrome.debugger.attach({ tabId }, "1.3"); attached = true;
      await chrome.debugger.sendCommand({ tabId }, "Emulation.setFocusEmulationEnabled", { enabled: true }).catch(() => {});
    }
    const host = await evalInTab(tabId, () => location.host);
    if (host !== "notebook.google.com") throw new Error("Google にログインしていません。ログインしてからやり直してください(" + host + ")");
    // アプリの初期化が終わり「ソースを追加」が出るまで待つ
    for (let i = 0; i < 60; i++) {
      if (await evalInTab(tabId, () => !!document.querySelector('button[aria-label="ソースを追加"]'))) break;
      if (i === 59) throw new Error("notebook の画面が準備できませんでした(URLを確認してください)");
      await sleep(500);
    }

    await chrome.scripting.executeScript({ target: { tabId }, files: ["page/uploader.js"], world: "MAIN" });
    await transferFiles(tabId, files);

    // クリック待ちで止まる処理なので、await せずに開始し、結果は window.__nblResult で受け取る
    await evalInTab(tabId, () => {
      window.__nblResult = null;
      window.__nblUploadFiles(window.__nblFiles, {}).then(
        (r) => (window.__nblResult = r),
        (e) => (window.__nblResult = { ok: false, reason: String((e && e.message) || e) })
      );
      return true;
    });

    // ボタンの座標が出たら本物のクリックを送る。結果が出るまで繰り返し確認する。
    const t0 = Date.now();
    let clicks = 0, lastClick = 0, result = null;
    while (Date.now() - t0 < 180000) {
      const st = await evalInTab(tabId, () => ({ need: window.__nblNeedClick || null, result: window.__nblResult || null }));
      if (st.result) { result = st.result; break; }
      // 裏タブで25秒たっても座標が出ない(描画が止まっている)場合のみ、一瞬だけ前面にして終わったら戻す
      if (createdTabId != null && !foregrounded && !st.need && Date.now() - t0 > 25000) {
        foregrounded = true;
        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
      }
      if (st.need && st.need.clickable !== false && clicks < 4 && Date.now() - lastClick > 4000) {
        if (!attached) { await chrome.debugger.attach({ tabId }, "1.3"); attached = true; }
        await trustedClick(tabId, st.need.x, st.need.y);
        clicks++;
        lastClick = Date.now();
        progress("アップロード中…");
      }
      await sleep(400);
    }
    if (!result) throw new Error("時間内に完了しませんでした");
    if (!result.ok) throw new Error(result.reason || "登録に失敗しました");

    const names = files.map((f) => f.name).join(", ") + (result.replaced ? "\n(同名の古いソース " + result.replaced + " 件を削除)" : "");
    if (result.deleteError) notify("nbl-del", "同名ソースの削除に失敗", result.deleteError + "\n重複して登録された可能性があります。");
    if (result.errorIconCount > 0) notify("nbl-warn", "追加しましたが警告があります", names + "\nノートブック側でエラー表示が出ている可能性があります。確認してください。");
    else notify("nbl-ok", "Notebook に追加しました", names);

    await waitNotebookIdle(tabId); // 取り込みが終わって落ち着くまで待つ(この後のスライド生成や次のジョブが取り込み中に動かないように)
    trace("登録完了 → スライド生成: " + (opts.slides ? "実行(" + s.slidesFormat + ")" : "しない(設定オフ/対象外)"));
    if (opts.slides) {
      const hh = { tabId, attached };
      const stop = startPump(hh);
      try { await generateSlidesInTab(tabId, s.slidesFormat, progress); } finally { stop(); attached = hh.attached; }
    }
  } finally {
    // デバッガの帯を消し、開いた裏のウィンドウ/タブを閉じる(既存のタブは閉じない)
    if (foregrounded && prevActive != null) await chrome.tabs.update(prevActive, { active: true }).catch(() => {});
    if (attached) await chrome.debugger.detach({ tabId }).catch(() => {});
    if (createdWindowId != null) await chrome.windows.remove(createdWindowId).catch(() => {});
    if (createdTabId != null) await chrome.tabs.remove(createdTabId).catch(() => {});
  }
}
