/**
 * lib.js — 拡張機能の「純粋関数」置き場(DOM にも chrome.* にも依存しない)
 *
 * 【なぜ分けているか】
 *   Service Worker(background.js)は importScripts("lib.js") で読み込む。
 *   同じファイルを Node からも require して単体テストできるようにするため、
 *   ブラウザ固有のAPIをここには書かない(DecompressionStream / TextDecoder / btoa など
 *   標準Web APIだけを使う)。
 *
 * 【含まれるもの】
 *   - ファイル名・MIME・拡張子の判定、Windows/Mac/Linux のパス → file:// URL 変換
 *   - 大きなバイト列を分割してページへ渡すための base64 変換
 *   - ZIP の読み取り(GitHub の archive.zip を展開するため。外部ライブラリは使わない)
 *   - リポジトリの中身を「ノートブックに登録できる Markdown」にまとめる処理
 *
 * 【ノートブック側の制約(公式ドキュメント記載)】
 *   ソースにできるのは PDF / TXT / MD / DOCX / PPTX / XLSX / 音声 / 画像など。ZIP は不可。
 *   さらに1ソースあたりの語数に上限があるため、大きなリポジトリは複数の Markdown に分割する。
 */
(function (root) {
  "use strict";

  // ───────────── ファイル名・MIME ─────────────
  const MIME = {
    pdf: "application/pdf",
    txt: "text/plain",
    md: "text/markdown",
    csv: "text/csv",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    mp3: "audio/mpeg",
    wav: "audio/wav",
  };

  const basename = (p) => String(p).split(/[\\/]/).pop();
  const extOf = (name) => {
    const m = /\.([^.\\/]+)$/.exec(String(name));
    return m ? m[1].toLowerCase() : "";
  };
  const guessMime = (name, fallback) => MIME[extOf(name)] || fallback || "application/octet-stream";

  /** "pdf, docx .md" のような設定文字列に拡張子が含まれるか。空設定なら全て許可。 */
  function extensionAllowed(name, list) {
    const set = new Set(
      String(list || "")
        .split(/[,\s]+/)
        .map((s) => s.replace(/^\./, "").toLowerCase())
        .filter(Boolean)
    );
    return set.size === 0 || set.has(extOf(name));
  }

  /**
   * chrome.downloads が返す絶対パスを file:// URL にする。
   * Windows の "C:\Users\a b\x.docx" も、Mac/Linux の "/Users/a/x.docx" も扱う。
   * encodeURI はドライブ文字の ":" を残すが、# と ? は URL の区切りと誤解されるので別途エンコードする。
   */
  function pathToFileUrl(p) {
    let s = String(p).replace(/\\/g, "/");
    if (s.startsWith("//")) return "file:" + encodeURI(s).replace(/#/g, "%23").replace(/\?/g, "%3F"); // UNC (\\server\share) → file://server/share
    if (!s.startsWith("/")) s = "/" + s;
    return "file://" + encodeURI(s).replace(/#/g, "%23").replace(/\?/g, "%3F");
  }

  /** Uint8Array → base64。String.fromCharCode に一度に渡せる個数に上限があるので小分けにする。 */
  function bytesToBase64(u8) {
    let s = "";
    const STEP = 0x8000;
    for (let i = 0; i < u8.length; i += STEP) s += String.fromCharCode.apply(null, u8.subarray(i, i + STEP));
    return btoa(s);
  }

  /** ファイル名に使えない文字を置き換える(ノートブック上の表示名にもなる)。 */
  function safeName(s) {
    return String(s).replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 120) || "file";
  }

  // ───────────── ZIP の読み取り ─────────────
  // ZIP の末尾にある「中央ディレクトリ」から一覧を読み、必要なエントリだけを展開する。
  // 圧縮方式は 0(無圧縮)と 8(deflate)のみ対応。GitHub の archive.zip はこの2つで足りる。

  /** ZIP のエントリ一覧を返す(中身はまだ展開しない)。 */
  function zipList(buf) {
    const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    // 末尾から "End of central directory" の署名(0x06054b50)を探す。コメントがあるので最大64KB遡る。
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 22 - 65535); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error("ZIP の終端が見つかりません(ZIP ではない可能性)");
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    if (count === 0xffff || p === 0xffffffff) throw new Error("ZIP64(4GB超 / 65535件超)には未対応です");
    const dec = new TextDecoder("utf-8");
    const entries = [];
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("ZIP の中央ディレクトリが壊れています");
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const usize = dv.getUint32(p + 24, true);
      const nlen = dv.getUint16(p + 28, true);
      const elen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
      entries.push({ name, method, csize, usize, lho });
      p += 46 + nlen + elen + clen;
    }
    return entries;
  }

  /** 1エントリを展開して Uint8Array で返す。 */
  async function zipRead(buf, entry) {
    const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const h = entry.lho;
    if (dv.getUint32(h, true) !== 0x04034b50) throw new Error("ZIP のローカルヘッダが不正です: " + entry.name);
    // データの開始位置は「ローカルヘッダ」側の名前長・拡張長で決まる(中央ディレクトリ側と値が違うことがある)
    const start = h + 30 + dv.getUint16(h + 26, true) + dv.getUint16(h + 28, true);
    const data = u8.subarray(start, start + entry.csize);
    if (entry.method === 0) return data;
    if (entry.method !== 8) throw new Error("未対応の圧縮方式(" + entry.method + "): " + entry.name);
    const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  // ───────────── リポジトリ → Markdown ─────────────
  const SKIP_DIR = /(^|\/)(node_modules|\.git|dist|build|out|vendor|__pycache__|\.next|\.nuxt|\.venv|venv|target|coverage|\.idea|\.vscode)\//;
  const SKIP_FILE = /(^|\/)(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|Cargo\.lock|poetry\.lock|Gemfile\.lock|composer\.lock|go\.sum|\.DS_Store)$/;
  const SKIP_EXT = new Set([
    "png", "jpg", "jpeg", "gif", "webp", "ico", "bmp", "tiff", "svg", "psd", "pdf", "zip", "gz", "tgz", "bz2", "xz", "7z", "rar", "tar",
    "woff", "woff2", "ttf", "otf", "eot", "mp3", "mp4", "mov", "avi", "webm", "wav", "flac",
    "exe", "dll", "so", "dylib", "class", "jar", "bin", "wasm", "pyc", "o", "a", "map", "lock",
  ]);
  const LANG = {
    js: "javascript", mjs: "javascript", cjs: "javascript", jsx: "jsx", ts: "typescript", tsx: "tsx", py: "python", rb: "ruby",
    go: "go", rs: "rust", java: "java", kt: "kotlin", swift: "swift", c: "c", h: "c", cpp: "cpp", cc: "cpp", hpp: "cpp",
    cs: "csharp", php: "php", sh: "bash", bash: "bash", zsh: "bash", ps1: "powershell", sql: "sql", html: "html", css: "css",
    scss: "scss", json: "json", yml: "yaml", yaml: "yaml", toml: "toml", xml: "xml", md: "markdown", txt: "", ini: "ini",
  };

  /** 内容に合わせて、本文中のバッククォート列より長いフェンス(```)を作る。コードブロックが途中で閉じないように。 */
  function fenceFor(text) {
    let longest = 0;
    for (const m of text.matchAll(/`+/g)) longest = Math.max(longest, m[0].length);
    return "`".repeat(Math.max(3, longest + 1));
  }

  function looksBinary(u8) {
    const n = Math.min(u8.length, 8000);
    for (let i = 0; i < n; i++) if (u8[i] === 0) return true; // NUL を含めばバイナリとみなす
    return false;
  }

  /**
   * パス名だけで「取り込まない」と決まる理由を返す(取り込むなら null)。
   * 中身を展開する【前】に呼べるので、node_modules などを展開せずに済む。
   */
  function pathSkipReason(path) {
    if (SKIP_DIR.test(path) || SKIP_FILE.test(path)) return "除外対象(依存物/ロックファイル等)";
    if (/\.min\.(js|css)$/.test(path)) return "minify済み";
    if (SKIP_EXT.has(extOf(path))) return "バイナリ/画像等";
    return null;
  }

  /**
   * ファイル1件分の Markdown 断片を作る。
   * 戻り値: { text } か、取り込まない場合は { skip: "理由" }
   */
  function fileSection(path, u8, opts) {
    const ext = extOf(path);
    const byPath = pathSkipReason(path);
    if (byPath) return { skip: byPath };
    if (u8.length > opts.maxFileBytes) return { skip: "大きすぎる(" + Math.round(u8.length / 1024) + "KB)" };
    if (looksBinary(u8)) return { skip: "バイナリ" };
    const body = new TextDecoder("utf-8").decode(u8).replace(/\r\n/g, "\n");
    if (ext === "md") return { text: "## `" + path + "`\n\n" + body.trimEnd() + "\n" }; // Markdown は入れ子にせず、そのまま載せる
    const fence = fenceFor(body);
    return { text: "## `" + path + "`\n\n" + fence + (LANG[ext] ?? ext) + "\n" + body.trimEnd() + "\n" + fence + "\n" };
  }

  /**
   * リポジトリの全ファイルを、ノートブックに登録できる Markdown(複数の場合あり)にまとめる。
   * input.files: [{ path, bytes }]  (path は ZIP 先頭のルートフォルダを除いた相対パス)
   * input.preSkipped: [{ path, reason }]  展開前に除外したファイル(任意)
   * 戻り値: { parts: [{ name, text }], included, skipped:[{path,reason}], truncated }
   */
  function buildRepoMarkdown(input, options) {
    const opts = Object.assign({ maxFileBytes: 200 * 1024, maxPartBytes: 1500 * 1024, maxParts: 6 }, options);
    const { owner, repo, ref, sourceUrl } = input;
    const included = [];
    const skipped = (input.preSkipped || []).slice(); // 展開前にパス名/サイズで除外した分
    for (const f of input.files) {
      const r = fileSection(f.path, f.bytes, opts);
      if (r.skip) skipped.push({ path: f.path, reason: r.skip });
      else included.push({ path: f.path, text: r.text, size: f.bytes.length });
    }
    // README を先頭に、残りは階層の浅い順 → パス順。全体像から読めるようにする。
    const rank = (p) => (/^readme/i.test(p) ? 0 : 1);
    included.sort((a, b) => rank(a.path) - rank(b.path) || a.path.split("/").length - b.path.split("/").length || a.path.localeCompare(b.path));

    const title = owner + "/" + repo + (ref && ref !== "HEAD" ? " @ " + ref : "");
    const head =
      "# " + title + "\n\nソース: " + sourceUrl + "\n\n" +
      "## ファイル一覧(" + included.length + "件)\n\n" +
      included.map((f) => "- `" + f.path + "` (" + f.size + " bytes)").join("\n") + "\n\n" +
      (skipped.length
        ? "## 取り込まなかったファイル(" + skipped.length + "件)\n\n" +
          skipped.slice(0, 200).map((s) => "- `" + s.path + "` — " + s.reason).join("\n") +
          (skipped.length > 200 ? "\n- …ほか " + (skipped.length - 200) + " 件" : "") + "\n\n"
        : "") +
      "---\n\n";

    // サイズで区切って分割する(1ソースあたりの語数上限に収めるため)
    const parts = [];
    let cur = head;
    let curBytes = head.length;
    let truncated = false;
    for (const f of included) {
      if (curBytes + f.text.length > opts.maxPartBytes && curBytes > head.length) {
        parts.push(cur);
        if (parts.length >= opts.maxParts) { truncated = true; cur = null; break; }
        cur = "# " + title + "(続き)\n\n---\n\n";
        curBytes = cur.length;
      }
      cur += f.text + "\n";
      curBytes += f.text.length + 1;
    }
    if (cur !== null) parts.push(cur);
    if (truncated) parts[parts.length - 1] += "\n\n> 容量の上限のため、これ以降のファイルは取り込んでいません。\n";

    const base = safeName(repo + (ref && ref !== "HEAD" ? "-" + ref : ""));
    return {
      parts: parts.map((text, i) => ({ name: base + (parts.length > 1 ? "-part" + (i + 1) : "") + ".md", text })),
      included: included.length,
      skipped,
      truncated,
    };
  }

  const api = { MIME, basename, extOf, guessMime, extensionAllowed, pathToFileUrl, bytesToBase64, safeName, zipList, zipRead, fenceFor, looksBinary, pathSkipReason, fileSection, buildRepoMarkdown };
  root.NBL = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : globalThis);
