const D = { notebookUrl: "", windowMode: "tab", extensions: "pdf,docx,pptx,xlsx,txt,md,csv", promptOnDownload: true, autoAdd: false, slidesAfterGithub: true, perRepoNotebook: false, slidesFormat: "pptx" };
const $ = (id) => document.getElementById(id);
(async () => {
  const s = { ...D, ...(await chrome.storage.sync.get(D)) };
  for (const k of Object.keys(D)) { const e = $(k); if (e.type === "checkbox") e.checked = s[k]; else e.value = s[k]; }
})();
$("save").onclick = async () => {
  const s = {};
  for (const k of Object.keys(D)) { const e = $(k); s[k] = e.type === "checkbox" ? e.checked : e.value.trim(); }
  if (s.notebookUrl && !/^https:\/\/notebook\.google\.com\/notebook\/[^/?#]+/.test(s.notebookUrl)) { $("st").textContent = "URLの形式が違います"; return; }
  await chrome.storage.sync.set(s); $("st").textContent = "保存しました";
};

// ── ノートブックの候補(名前 + ID)をプルダウンに出す。取得は background が notebook.google.com のホームを裏で開いて行う。
const pick = $("nbPick"), st = $("nbStatus");
async function renderPick() {
  const { notebookCache } = await chrome.storage.local.get("notebookCache");
  const { notebooks = [] } = await chrome.storage.sync.get("notebooks");
  const seen = new Set(), items = [...(notebookCache?.items || []), ...notebooks].filter((n) => !seen.has(n.url) && seen.add(n.url));
  pick.innerHTML = '<option value="">— 選んでください —</option>';
  for (const n of items) {
    const id = (/\/notebook\/([0-9a-f-]{36})/.exec(n.url) || [])[1] || "";
    const o = document.createElement("option"); o.value = n.url;
    o.textContent = (n.emoji || "") + (n.title || "無題") + "  [" + id.slice(0, 8) + "]" + (n.meta ? "  — " + n.meta : "");
    pick.append(o);
  }
  pick.value = $("notebookUrl").value;
  return notebookCache;
}
pick.onchange = () => { if (pick.value) $("notebookUrl").value = pick.value; };
$("nbRefresh").onclick = async () => {
  st.textContent = "取得中…(Google にログインしている必要があります)";
  const r = await chrome.runtime.sendMessage({ type: "refresh-notebooks" });
  await renderPick();
  st.textContent = r?.ok ? r.notebooks.length + "件取得しました" : "失敗: " + (r?.error || "");
};
// 設定の読み込み(上の即時関数)が終わってから候補を描画する
setTimeout(renderPick, 300);
